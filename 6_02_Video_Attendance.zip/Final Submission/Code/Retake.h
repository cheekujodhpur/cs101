/*
A Video Attendance Module
Copyright (C) Slot 6:Group 2:Reebhu,Keshav,Ayush,Kshitij

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
*/

#pragma once

/*External Libraries*/
#include<iostream>
#include<opencv2\core\core.hpp>
#include<stdlib.h>
#include <iostream>
#include <fstream>
#include <string>

/*Header Files*/
#include"Detect.h"
#include"Main.h"

namespace VAM {

	/*namespaces*/
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/*Retake photos for said student*/
		public ref class Retake : public System::Windows::Forms::Form
		{
		public:
			/*Constructor*/
			Retake(void)
			{
				/*Init components*/
				InitializeComponent();
			}

		protected:
			/*Destructor*/
			~Retake()
			{
				if (components)
				{
					delete components;
				}
			}
		private: System::Windows::Forms::Label^  label2;
		private: System::Windows::Forms::TextBox^  textBox2;
		private: System::Windows::Forms::ProgressBar^  progressBar1;
		private: System::Windows::Forms::Button^  button4;
		private: System::Windows::Forms::Button^  button1;
		private: System::Windows::Forms::Button^  button2;
		private:
			/*Init Component Model*/
			System::ComponentModel::Container ^components;

	#pragma region Windows Form Designer generated code
			/*Init components*/
			void InitializeComponent(void)
			{
				this->label2 = (gcnew System::Windows::Forms::Label());
				this->textBox2 = (gcnew System::Windows::Forms::TextBox());
				this->progressBar1 = (gcnew System::Windows::Forms::ProgressBar());
				this->button4 = (gcnew System::Windows::Forms::Button());
				this->button1 = (gcnew System::Windows::Forms::Button());
				this->button2 = (gcnew System::Windows::Forms::Button());
				this->SuspendLayout();
				// 
				// label2
				// 
				this->label2->AutoSize = true;
				this->label2->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
					static_cast<System::Byte>(0)));
				this->label2->Location = System::Drawing::Point(34, 65);
				this->label2->Name = L"label2";
				this->label2->Size = System::Drawing::Size(189, 28);
				this->label2->TabIndex = 15;
				this->label2->Text = L"Enter Roll Number:";
				// 
				// textBox2
				// 
				this->textBox2->Location = System::Drawing::Point(253, 71);
				this->textBox2->Name = L"textBox2";
				this->textBox2->Size = System::Drawing::Size(252, 22);
				this->textBox2->TabIndex = 16;
				// 
				// progressBar1
				// 
				this->progressBar1->Location = System::Drawing::Point(114, 151);
				this->progressBar1->Name = L"progressBar1";
				this->progressBar1->Size = System::Drawing::Size(305, 46);
				this->progressBar1->TabIndex = 17;
				this->progressBar1->Visible = false;
				// 
				// button4
				// 
				this->button4->Location = System::Drawing::Point(28, 264);
				this->button4->Name = L"button4";
				this->button4->Size = System::Drawing::Size(116, 36);
				this->button4->TabIndex = 33;
				this->button4->Text = L"Back";
				this->button4->UseVisualStyleBackColor = true;
				this->button4->Click += gcnew System::EventHandler(this, &Retake::button4_Click);
				// 
				// button1
				// 
				this->button1->Location = System::Drawing::Point(216, 264);
				this->button1->Name = L"button1";
				this->button1->Size = System::Drawing::Size(116, 36);
				this->button1->TabIndex = 34;
				this->button1->Text = L"Clear";
				this->button1->UseVisualStyleBackColor = true;
				this->button1->Click += gcnew System::EventHandler(this, &Retake::button1_Click);
				// 
				// button2
				// 
				this->button2->Location = System::Drawing::Point(389, 264);
				this->button2->Name = L"button2";
				this->button2->Size = System::Drawing::Size(116, 36);
				this->button2->TabIndex = 35;
				this->button2->Text = L"Re-Train";
				this->button2->UseVisualStyleBackColor = true;
				this->button2->Click += gcnew System::EventHandler(this, &Retake::button2_Click);
				// 
				// Retake
				// 
				this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
				this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
				this->ClientSize = System::Drawing::Size(532, 312);
				this->Controls->Add(this->button2);
				this->Controls->Add(this->button1);
				this->Controls->Add(this->button4);
				this->Controls->Add(this->progressBar1);
				this->Controls->Add(this->textBox2);
				this->Controls->Add(this->label2);
				this->Name = L"Retake";
				this->Text = L"Retake";
				this->ResumeLayout(false);
				this->PerformLayout();

			}
	#pragma endregion
		private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
			/*Retake data init*/
			string roll;
			bool flag = false;

			/*Input File init*/
			ifstream InFile;
			InFile.open("stu_index.txt");
			InFile >> __Student_Current_Index;
			InFile.close();

			/*FileStorage for Students*/
			cv::FileStorage f("students.yml", cv::FileStorage::READ);
			MarshalString(textBox2->Text, roll);
			Student_Info retakestudent;

			for (int j = 0; j < __Student_Current_Index; j++)
			{
				string temp = "s_" + to_string(j);
				f[temp] >> retakestudent;
				if (retakestudent.roll_no == roll)
				{
					flag = true;
				}
			}
			if (flag)
			{
				/*Retake data*/
				int y;
				progressBar1->Visible = true;
				do
				{
					y = videoFaceDetect(roll);
					progressBar1->Value = (y * 100 / __Num_Photos);

				} while (y != __Num_Photos);
				progressBar1->Visible = false;
				MessageBox::Show("Done!");
			}
			else
			{
				MessageBox::Show("Roll Number not found!");
					textBox2->Text = "";
			}
		}
		private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) {
			/*close*/
			this->Hide();
		}
		private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			/*clear*/
			textBox2->Text = "";
		}
	};
}
