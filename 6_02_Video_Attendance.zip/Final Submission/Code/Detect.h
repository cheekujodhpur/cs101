/*
A Video Attendance Module
Copyright (C) Slot 6:Group 2:Reebhu,Keshav,Ayush,Kshitij

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
*/

#ifndef HEADER_H
#define HEADER_H
/*Library Functions*/
#include <iostream>
#include <opencv2/objdetect/objdetect.hpp>
#include <opencv2/contrib/contrib.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <string>
#include <vector>
int videoFaceDetect(std::string output_folder);//function to detect faces from continuous video stream from any attached camera device 
int DetectAndCrop(std::string output_folder, cv::Mat &img, cv::Vector<cv::Mat> &output);//function to detect faces in given image, crop the faces and store them in separate files
int display_caption(cv::Mat &A, cv::Mat &B, char* ch, char* winname, int del);//function which displays a text in  a new window
int display_image(cv::Mat &A, char* winname, int del);//function to display an image in a new window 
int smoothImage(char* img);//performs several linear smoothing operations on an image
void videoFaceDetect2(cv::Mat*img);
#endif
