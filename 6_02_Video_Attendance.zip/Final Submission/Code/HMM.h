/*
This program detects faces in continuous video stream from webcam and shows the cropped faces,

also storing them in consecutively numbered files

Copyright (C) <2014> <Group 02: Kumar Ayush, Reebhu Bhattacharyya, Kshitij Bajaj, Keshav Srinivasan>

This program is free software: you can redistribute it and/or modify

it under the terms of the GNU General Public License as published by

the Free Software Foundation, either version 3 of the License, or

(at your option) any later version.

This program is distributed in the hope that it will be useful,

but WITHOUT ANY WARRANTY; without even the implied warranty of

MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the

GNU General Public License for more details.

You should have received a copy of the GNU General Public License

along with this program. If not, see <http://www.gnu.org/licenses/>.

*/
#ifndef HMM_H
#define HMM_H
#include <iostream>
#include <fstream>
#include <opencv2/core/core.hpp>
#include <opencv2/contrib/contrib.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <sstream>
#include <cmath>
#include <string>
#include <conio.h>
using namespace std;
using namespace cv;
//defining value of pi
#define PI 3.141592653589793238

//reciprocal of square root of 2
#define INVSQRT2 1.414213562373095048801688724209 * 0.5

//size of sliding window
#define SW_SIZE 32      

//	extent of overlap
#define OVERLAP 0.5     

//	extent by which to slide the window
#define APP_SIZE (int)((1-OVERLAP)*SW_SIZE)

//	reciprocal of window size
#define INV2SW_SIZE (1.0)/(SW_SIZE)

//	definition of row size of image
#define IMG_ROW 96

//	definition of column size of image
#define IMG_COL 96

//	total number of DCT matrices the image will produce
#define DCT_NUM1 (int)((IMG_ROW-SW_SIZE+APP_SIZE)/APP_SIZE)    

//	total number of DCT matrices the image will produce
#define DCT_NUM2 (int)((IMG_COL-SW_SIZE+APP_SIZE)/APP_SIZE)

//	threshold limit for error
#define EPSILON 1E-200 

//	declaration of matrix of matrices holding DCT coefficients
double DCT[DCT_NUM1*DCT_NUM2][SW_SIZE][SW_SIZE];

//	declaration of an observation sequence
Obs *O = new Obs;

/*
* Uses LU Decomposition to find the inverse of nxn matrix
* It takes as parameter a pointer to a two-dimensional square array and the dimension of te array as parameters.
* The size should be positive.
* The inverse matrix is stored in the original one itself.
*/
void Invert(double** A, int n)
{
	//check for null pointer
	if (A == NULL)return;

	//declare pointers to upper and lower triangular matrices
	double **U, **L;

	//initialize the two pointers to store nxn matrices
	U = new double*[n];
	L = new double*[n];
	for (int iter = 0; iter < n; iter++)
	{
		U[iter] = new double[n];
		L[iter] = new double[n];
	}

	//declare loop variables and a temporary holder variable sum
	int i, j, k;
	double sum = 0;

	//initialize the upper triangular matrix
	for (i = 0; i < n; i++) {
		U[i][i] = 1;
	}

	/*
	*	The following lines compute the LU decomposition of the nxn matrix using Crout's decompositon algorithm
	*	In the algorithm, the L matrix is computed recursively(in terms of itself) columnwise starting from the first column,
	*	and the U matrix is computed, also recursively, from the L matrix rowwise, starting from the first row.
	*/
	for (j = 0; j < n; j++) {

		/*
		*	compute the j th colum of the L matrix,
		*	since the lower triangular part consists of those positions whose row index is greater than column index
		*	the iteration starts from j
		*/
		for (i = j; i < n; i++) {

			//initialize sum to 0 at beginnig of each iteration 
			sum = 0;
			for (k = 0; k < j; k++)
			{
				//compute the term to be subtratced from the value of the element at [i][j] position 
				sum = sum + L[i][k] * U[k][j];
			}

			//set the value of L[i][j]
			L[i][j] = A[i][j] - sum;
		}

		/*
		*	compute the j th row of the U matrix,
		*	since the upper triangular part consists of those positions whose column index is greater than index index
		*	the iteration starts from j
		*/
		for (i = j; i < n; i++) {
			//initialize sum to 0 at beginnig of each iteration 
			sum = 0;
			for (k = 0; k < j; k++)
			{
				//compute the term to be subtratced from the value of the element at [i][j] position 
				sum = sum + L[j][k] * U[k][i];
			}

			//since for computing U[j][i] we have to divide by L[j][j], checking if L[j][j] is zero indix=cating matrix is singular
			if (L[j][j] == 0)
			{
				//print appropriate error message and return
				cout << "Determinant is close to 0!\n Can't divide by 0...\n";
				return;
			}

			//set the value of U[j][i]
			U[j][i] = (A[j][i] - sum) / L[j][j];
		}
	}

	/*
	*	we are going to solve for the inverse of the matrix column by column,
	*	using Ax=b , where b are the columns of the identity matrix and x is the column of the inverse matrix
	*/

	//b is the identity matrix, d is an intermediate matrix needed o compute the inverse from LU matrices, s is a temporary holding variable
	double b[15][15] = { 0 }, s = 0;
	double d[15][15];

	//initializing the columns of the identity matrix
	for (i = 0; i<n; i++)b[i][i] = 1;

	// LUx=b can be viewed as two simultaneous equations, Ld=b, Ux=d and x can be computed easily by first computing d
	for (j = 0; j<n; j++)
	{
		//solve for d using the technique of Gaussian elimination
		d[0][j] = b[0][j] / L[0][0];
		for (i = 1; i<n; i++)
		{
			//intitializing the temporary variable to zero at the start of each iteration
			s = 0;

			for (k = 0; k<i; k++)
				s += L[i][k] * d[k][j];

			//computing element [i][j] of d
			d[i][j] = (b[i][j] - s) / L[i][i];
		}
	}

	/*
	*	Once d is computed we can compute the columns of the inverse matrix by solving the quation Ux=d
	*	Since we are replacing the values in the original matrix itself with the inverse matrix values, x here stands for a column of A
	*/

	//iterating over all columns
	for (j = 0; j<n; j++)
	{
		A[n - 1][j] = d[n - 1][j];

		//starting from ending row which contains only one element and hence trivial to solve
		for (int i = n - 2; i >= 0; i--)
		{
			//intitializing the temporary variable to zero at the start of each iteration
			s = 0;

			for (k = n - 1; k>i; k--)
				s += U[i][k] * A[k][j];

			//computing element [i][j] of inverse matrix
			A[i][j] = d[i][j] - s;
		}
	}
}

/*
*	This function computes the determinant of a nxn matrix, passed as a pointer by LU Factorization method
*	It takes as input the matrix as a pointer and the size.
*	The size should be positive.
*/
double Determinant(double **A, int n)
{
	//check for null pointer
	if (A == NULL)return 0;

	//declare pointers to upper and lower triangular matrices
	double **U, **L;

	//initialize the two pointers to store nxn matrices
	U = new double*[n];
	L = new double*[n];
	for (int iter = 0; iter < n; iter++)
	{
		U[iter] = new double[n];
		L[iter] = new double[n];
	}

	//declare loop variables and a temporary holder variable sum
	int i, j, k;
	double sum = 0;

	//declare variable to store determinant and initialzie it with 1
	double det = 1.0;

	//initialize the upper triangular matrix
	for (i = 0; i < n; i++) {
		U[i][i] = 1;
	}

	/*
	*	The following lines compute the LU decomposition of the nxn matrix using Crout's decompositon algorithm
	*	In the algorithm, the L matrix is computed recursively(in terms of itself) columnwise starting from the first column,
	*	and the U matrix is computed, also recursively, from the L matrix rowwise, starting from the first row.
	*/
	for (j = 0; j < n; j++) {

		/*
		*	compute the j th colum of the L matrix,
		*	since the lower triangular part consists of those positions whose row index is greater than column index
		*	the iteration starts from j
		*/
		for (i = j; i < n; i++) {

			//initialize sum to 0 at beginnig of each iteration 
			sum = 0;
			for (k = 0; k < j; k++)
			{
				//compute the term to be subtratced from the value of the element at [i][j] position 
				sum = sum + L[i][k] * U[k][j];
			}

			//set the value of L[i][j]
			L[i][j] = A[i][j] - sum;
		}

		/*
		*	compute the j th row of the U matrix,
		*	since the upper triangular part consists of those positions whose column index is greater than index index
		*	the iteration starts from j
		*/
		for (i = j; i < n; i++) {
			//initialize sum to 0 at beginnig of each iteration 
			sum = 0;
			for (k = 0; k < j; k++)
			{
				//compute the term to be subtratced from the value of the element at [i][j] position 
				sum = sum + L[j][k] * U[k][i];
			}

			//since for computing U[j][i] we have to divide by L[j][j], checking if L[j][j] is zero indix=cating matrix is singular
			if (L[j][j] == 0)
			{
				//print appropriate error message and return
				cout << "Determinant is close to 0!\n Can't divide by 0...\n";
				return 0;
			}

			//set the value of U[j][i]
			U[j][i] = (A[j][i] - sum) / L[j][j];
		}
	}

	//Compute the determinant from the diagonal entries of the lower triangular matrix
	for (int i = 0; i<n; i++)
		det *= L[i][i];

	//return determinant
	return det;
}

/*
*	The following is a class declaration.
*	The class NRowVector implements a n-dimensional row vector as an OpenCV Mat and
*	provides functionalities for accessing,setting its elements etc.
*	Later on, we also define operations on vectors.
*/
class NRowVector
{
	//member variables of the class NRowVector

	//pointer to a Mat on heap memory that will store the elements of the row-vector
	Mat* v;

	//stores size, i.e. dimensionality, of the row-vector
	int size;

public:

	//public section of the class

	//constructor definitions

	/*
	*	Default constructor for the class.
	*	Creates a default row vector of dimension 3 and initializes each element to zero
	*	If new returns a null pointer, it displays appropriate error message
	*/
	NRowVector()
	{
		//initialize size to default value of 3
		size = 3;

		//create a Mat on heap of dimensions 1x3 and store a pointer to it
		v = new Mat(1, 3, CV_64F, Scalar(0));

		//If a null pointer is returned, display appropriate error message
		if (v == NULL)
		{
			cout << "Null pointer returned during initialization of NRowVector." << endl;
		}
	}

	/*
	*	Overloaded parametrized constructor for the class.
	*	Creates a row vector of dimension s and initializes each element with the elements of a double array provided as parameter
	*	If new returns a null pointer, it displays appropriate error message
	*/
	NRowVector(int s, double *arr)
	{
		//initialize size with the value passed as parameter
		size = s;

		//create a Mat on heap of dimensions 1xs and store a pointer to it
		v = new Mat(1, size, CV_64F);

		//If a null pointer is returned, display appropriate error message
		if (v == NULL)
		{
			cout << "Null pointer returned during initialization of NRowVector." << endl;
		}

		//otherwise initialize the vecto with values provided
		else
			for (int j = 0; j < size; j++)
				v->at<double>(0, j) = arr[j];

	}

	/*
	*	Overloaded parametrized constructor for the class.
	*	Creates a row vector of dimension s and initializes each element with 0
	*	If new returns a null pointer, it displays appropriate error message
	*/
	NRowVector(int s)
	{
		//initialize size with the value passed as parameter
		size = s;

		//create a Mat on heap of dimensions 1xs and store a pointer to it
		v = new Mat(1, s, CV_64F, Scalar(0));

		//If a null pointer is returned, display appropriate error message
		if (v == NULL)
		{
			cout << "Null pointer returned during initialization of NRowVector." << endl;
		}
	}

	/*
	*	The copy constructor for the class
	*/
	NRowVector(const NRowVector& v1)
	{
		//set size equal to the size of v1
		size = v1.size;

		//allocate new space on heap for Mat which will store the copy and store its pointer
		v = new Mat(1, size, CV_64F);

		//display appropriate error message if null pointer is returned
		if (v == NULL)
		{
			cout << "Null pointer returned during initialization of NRowVector." << endl;
		}

		//set each element of the new vecotr equal to corresponding element of v1
		for (int j = 0; j < size; j++)
			setElement(j, v1.getElement(j));
	}

	/*
	*	Destructor for the class, which releases the memory on heap occupied by the Mat
	*/
	~NRowVector()
	{
		delete v;
		v = NULL;
	}

	/*
	* This function provides easy access to the ith element of the row vector
	* The position passed as parameter should satisfy 0<=pos<n, where n is the size of the vector
	*/
	double getElement(int pos) const
	{
		return v->at<double>(0, pos);
	}

	/*
	* This function provides easy way to set the ith element of the row vector to a new value
	* The position passed as parameter should satisfy 0<=i<n, where n is the size of the vector
	* The value can be any real number
	*/
	void setElement(int pos, double val)
	{
		v->at<double>(0, pos) = val;
	}

	/*
	*	This is an accessor function that returns the member variable size
	*/
	int getSize() const
	{
		return size;
	}

	/*
	This function returns the norm of the column vector
	*/
	double getNorm() const
	{
		//	initialize norm to 0
		double norm = 0.0;

		//get the sum of squares of all elements of the vector
		for (int j = 0; j < size; j++)
		{
			norm += getElement(j)*getElement(j);
		}

		//norm is the square root of the sum of squares of the elements
		return sqrt(norm);
	}

	/*
	*	Overloaded '=' operator for the class that equates a NRowVector object to a double value
	*	It forms a unit vector whose norm is the value it is being equated to
	*	 and returns the vector after having equated it.
	*/
	NRowVector operator=(double d)
	{
		//compute value of each element of the vector
		double tmp = sqrt(d*d / size);

		//set each element equal to the value computed
		for (int j = 0; j < size; j++)setElement(j, tmp);

		//return the modified vector
		return *this;
	}

	/*
	*	Overloaded '=' operator for the class that equates a NRowVector object to another NRowVector object
	*	It copies the elements of the RHS object into its own Mat and updates the size
	*	 and returns the vector after having equated it.
	*/
	NRowVector operator=(const NRowVector &v1)
	{
		//	update the size of the object to receive the new values
		size = v1.size;

		//	deallocate memory for the Mat oject it originally held
		delete v;

		//	allocate memory for a new Mat object of the desired new size
		v = new Mat(1, size, CV_64F);

		// if new returns a null pointer, then return a default vector after printing appropriate error message
		if (v == NULL)
		{
			cout << "Null pointer returned during initialization of NRowVector." << endl;
			return NRowVector();
		}

		//copy the elements of RHS vector into the newly created Mat
		for (int j = 0; j < size; j++)setElement(j, v1.getElement(j));

		//return itself
		return *this;
	}

	/*
	*	The following function returns a pointer to a matrix(one-dimensional array elements stored as cv::Mat object) containing elements of the vector
	*/
	Mat* convertToMat()
	{
		int r = 1;
		int c = size;

		//	declare a new Mat of the required dimensions for storing elements of the array
		Mat* m = new Mat(r, c, CV_64F);

		//	print appropriate error message if null pointer is returned
		if (m == NULL)
		{
			cout << "Null pointer returned during initialization of Mat." << endl;
			return NULL;
		}

		//	copy the elements of the vector into the matrix
		for (int j = 0; j < size; j++)
		{
			m->at<double>(0, j) = getElement(j);
		}

		//	return the pointer to the Mat
		return m;
	}
};
//end of NRowVector class

/*
*	The following is a class declaration.
*	The class NColVector implements a n-dimensional column vector as an OpenCV Mat and
*	provides functionalities for accessing,setting its elements etc.
*	Later on, we also define operations on vectors.
*/
class NColVector
{
	//member variables of the class NColVector

	//pointer to a Mat on heap memory that will store the elements of the column-vector
	Mat* v;

	//stores size, i.e. dimensionality, of the row-vector
	int size;

public:

	//public section of the class

	//constructor definitions

	/*
	*	Default constructor for the class.
	*	Creates a default column vector of dimension 3 and initializes each element to zero
	*	If new returns a null pointer, it displays appropriate error message
	*/
	NColVector()
	{
		//	initialize size to default value of 3
		size = 3;

		//	create a Mat on heap of dimensions 3x1 and store a pointer to it
		v = new Mat(3, 1, CV_64F, Scalar(0));

		//	If a null pointer is returned, display appropriate error message
		if (v == NULL)
		{
			cout << "Null pointer returned during initialization of NColVector." << endl;
		}
	}

	/*
	*	Overloaded parametrized constructor for the class.
	*	Creates a column vector of dimension s and initializes each element with the elements of a double array provided as parameter
	*	If new returns a null pointer, it displays appropriate error message
	*/
	NColVector(int s, double *arr)
	{
		//	initialize size to value passed as parameter
		size = s;

		//	create a Mat on heap of dimensions sx1 and store a pointer to it
		v = new Mat(size, 1, CV_64F);

		//	If a null pointer is returned, display appropriate error message
		if (v == NULL)
		{
			cout << "Null pointer returned during initialization of NColVector." << endl;
		}

		//set the values of each element of vector with values passed in the double array
		for (int j = 0; j < size; j++)
			v->at<double>(j, 0) = arr[j];

	}

	/*
	*	Overloaded parametrized constructor for the class.
	*	Creates a column vector of dimension s and initializes each element with 0
	*	If new returns a null pointer, it displays appropriate error message
	*/
	NColVector(int s)
	{
		//	initialize size with the value passed as parameter
		size = s;

		//	create a Mat on heap of dimensions 1xs and store a pointer to it
		v = new Mat(s, 1, CV_64F, Scalar(0));

		//	If a null pointer is returned, display appropriate error message
		if (v == NULL)
		{
			cout << "Null pointer returned during initialization of NRowVector." << endl;
		}
	}

	/*
	*	Overloaded parametrized constructor for the class.
	*	Creates a column vector of dimension s and initializes each element with the second parameter passed to the function
	*	If new returns a null pointer, it displays appropriate error message
	*/
	NColVector(int s, double d)
	{
		//	initialize size with the value passed as parameter
		size = s;

		//	create a Mat on heap of dimensions 1xs and store a pointer to it
		v = new Mat(s, 1, CV_64F, Scalar(d));

		//	If a null pointer is returned, display appropriate error message
		if (v == NULL)
		{
			cout << "Null pointer returned during initialization of NColVector." << endl;
		}
	}

	/*
	Overloaded parametrized constructor for the class which creates a column vector from a row vector taken as parameter
	*/
	NColVector(const NRowVector v1)
	{
		//	get size of row vector and set the size of the column vector equal to it
		size = v1.getSize();

		//	create a new Mat of required dimensions sizex1 for storing the elements of the row vector
		v = new Mat(size, 1, CV_64F);

		//	display appropriate error message if null pointer is returned
		if (v == NULL)
		{
			cout << "Null pointer returned during initialization of NColVector." << endl;
		}

		//	set each element of the column vector equal to corresponding element of the row vector
		for (int j = 0; j < size; j++)
			setElement(j, v1.getElement(j));
	}

	/*
	*	The copy constructor for the class
	*/
	NColVector(const NColVector &v1)
	{
		//	set size equal to the size of v1
		size = v1.size;

		//	allocate new space on heap for Mat which will store the copy and store its pointer
		v = new Mat(size, 1, CV_64F);

		//	display appropriate error message if null pointer is returned
		if (v == NULL)
		{
			cout << "Null pointer returned during initialization of NColVector." << endl;
		}

		//	set each element of the new vecotr equal to corresponding element of v1
		for (int j = 0; j < size; j++)
			setElement(j, v1.getElement(j));
	}

	/*
	*	Destructor for the class, which releases the memory on heap occupied by the Mat
	*/
	~NColVector()
	{
		delete v;
	}

	/*
	* This function provides easy access to the ith element of the column vector
	* The position passed as parameter should satisfy 0<=pos<n, where n is the size of the vector
	*/
	double getElement(int i) const
	{
		return v->at<double>(i, 0);
	}

	/*
	* This function provides easy way to set the ith element of the row vector to a new value
	* The position passed as parameter should satisfy 0<=i<n, where n is the size of the vector
	* The value can be any real number
	*/
	void setElement(int pos, double val)
	{
		v->at<double>(pos, 0) = val;
	}

	/*
	*	This is an accessor function that returns the member variable size
	*/
	int getSize() const
	{
		return size;
	}

	/*
	This function returns the norm of the column vector
	*/
	double getNorm() const
	{
		//	initialize norm to 0
		double norm = 0.0;

		//get the sum of squares of all elements of the vector
		for (int j = 0; j < size; j++)
		{
			norm += getElement(j)*getElement(j);
		}

		//norm is the square root of the sum of squares of the elements
		return sqrt(norm);
	}

	/*
	*	The function returns the transpose of the column vector as a row vector object
	*/
	NRowVector transpose()
	{
		//	create a row vector of size equal to the column vector
		NRowVector v2(getSize());

		//	set each element of the row vector equal to corresponding element of the column vector
		for (int j = 0; j < getSize(); j++)v2.setElement(j, getElement(j));

		//return the NRowVector object
		return v2;
	}

	/*
	*	Overloaded '=' operator for the class that equates a NRowVector object to a double value
	*	It forms a unit vector whose norm is the value it is being equated to
	*	 and returns the vector after having equated it.
	*/
	NColVector& operator=(double d)
	{
		//	compute value of each element of the vector
		double tmp = sqrt(d*d / size);

		//	set each element equal to the value computed
		for (int j = 0; j < size; j++)setElement(j, tmp);

		//	return the modified vector
		return *this;
	}

	/*
	*	Overloaded '=' operator for the class that equates a NRowVector object to another NRowVector object
	*	It copies the elements of the RHS object into its own Mat and updates the size
	*	 and returns the vector after having equated it.
	*/
	NColVector& operator=(const NColVector& v1)
	{
		//	update the size of the object to receive the new values
		size = v1.size;

		//	deallocate memory for the Mat oject it originally held
		delete v;

		//	allocate memory for a new Mat object of the desired new size
		v = new Mat(size, 1, CV_64F);

		//	deallocate memory for the Mat oject it originally held
		if (v == NULL)
		{
			cout << "Null pointer returned during initialization of NColVector." << endl;
		}

		//	copy the elements of RHS vector into the newly created Mat
		for (int j = 0; j < size; j++)setElement(j, v1.getElement(j));

		//	return itself
		return *this;
	}

	/*
	*	The following function returns a matrix(one-dimensional array elements stored as cv::Mat object) containing elements of the vector
	*/
	Mat convertToMat()
	{
		Mat m(*v);
		return m;
	}

};
//end of class NColVector

/*
*	The following is a class definition.
*	It implements an observation sequence as a cv::Mat object.
*	It can take a sequence of DCT coefficients for an image and create an observation sequence by extracting the first 15 elements
*	of each DCT matrix
*/
class Obs
{
	//	member variables

	//	pointer to a Mat object which will store the observation sequence
	Mat* obs;
public:
	//	public section of the class

	/*
	*	Default constructor for the class
	*	Initializes a matrix of the size of a single observation and sets all its elements to 0.
	*/
	Obs()
	{
		//	initialize a new matrix
		obs = new Mat(1, 15, CV_64F, Scalar(0));

		//	print error message if null pointer is returned
		if (obs == NULL)
		{
			cout << "Null pointer returned during initialization of Obs." << endl;
		}
	}

	/*
	*	Overloaded parametrized constructor for the class
	*	Initializes a matrix of observation sequences of a single image based on the DCT cofficients of the image passed as parameter
	*	It also takes the number of DCT matrices or the size of the observation sequence as a parameter
	*/
	Obs(double D[][SW_SIZE][SW_SIZE], int size)
	{
		//	create a new Mat whose number of rows is the number of DCT coefficients we are going to store and the number of columns is the size of the observation sequence
		//	Thus each observation is stored as a column vector
		obs = new Mat(15, size, CV_64F, Scalar(0));

		//	iterate over each of the DCt matrices, the total number of DCT matrices is gven by size of the observation sequence
		for (int i = 0; i < size; i++)
		{
			//	Extract the first 15 elements of each of the DCT matrice, by scanning it in a zig-zag fashion
			for (int k = 0, counter = 0; k < 5; k++)
			{
				for (int j = 0; j <= k; j++, counter++)
				{
					if (k % 2 == 0) obs->at<double>(counter, i) = (double)(D[i][k - j][j]);
					else obs->at<double>(counter, i) = (double)D[i][j][k - j];
				}
			}

			//	normalize each of the DCT coefficients so that they lie betwen common limits
			double max = -DBL_MAX, min = DBL_MAX;

			//	find the maximum and minimum of the DCT coefficients for scaling
			for (int iter = 0; iter < 15; iter++)
			{
				if (obs->at<double>(iter, i) > max)max = obs->at<double>(iter, i);
				else if (obs->at<double>(iter, i) < min)min = obs->at<double>(iter, i);
			}

			//	rescale each of the DCT coefficients
			for (int iter = 0; iter < 15; iter++)
			{
				obs->at<double>(iter, i) = obs->at<double>(iter, i) / (max - min);
			}
		}
	}

	/*
	*	This function displays the entire observation sequence
	*/
	void disp()
	{
		//	set format flags so as to display the floating point numbers in non0scientific format
		cout.setf(ios::fixed);

		//	display each observation
		for (int c = 0; c < obs->cols; c++)
		{
			for (int r = 0; r < 15; r++)
			{
				cout << obs->at<double>(r, c) << "\t";
			}
			cout << endl;
		}

		//	revert the format flag changes
		cout.unsetf(ios::fixed);
	}

	/*
	*	The copy constructor for the class
	*/
	Obs(const Obs &o)
	{
		//	creates a clone of the observation matrix
		obs = new Mat(o.obs->clone());
	}

	/*
	*	Overloaded '=' operator for the class
	*/
	Obs& operator=(const Obs &o)
	{
		//deallocate memory of the old observation matrix
		delete obs;

		//	creates a copy of the observation matrix and stores it as a new matrix
		obs = new Mat(o.obs->clone());

		//return the modified object
		return *this;
	}

	/*
	*	Destructor for the class which deallocates memory for the observation matrix on the heap
	*/
	~Obs()
	{
		delete obs;
		obs = NULL;
	}

	/*
	*	Reset or create a new observation sequence from the DCT coefficients of a single image passed as parameter
	*	It also takes the number of DCT matrices or the size of the observation sequence as a parameter
	*/
	void setObs(double D[][SW_SIZE][SW_SIZE], int size)
	{
		//	create a new Mat whose number of rows is the number of DCT coefficients we are going to store and the number of columns is the size of the observation sequence
		//	Thus each observation is stored as a column vector
		obs = new Mat(15, size, CV_64F, Scalar(0));

		//	iterate over each of the DCt matrices, the total number of DCT matrices is gven by size of the observation sequence
		for (int i = 0; i < size; i++)
		{
			//	Extract the first 15 elements of each of the DCT matrice, by scanning it in a zig-zag fashion
			for (int k = 0, counter = 0; k < 5; k++)
			{
				for (int j = 0; j <= k; j++, counter++)
				{
					if (k % 2 == 0) obs->at<double>(counter, i) = (double)(D[i][k - j][j]);
					else obs->at<double>(counter, i) = (double)D[i][j][k - j];
				}
			}

			//	normalize each of the DCT coefficients so that they lie betwen common limits
			double max = -DBL_MAX, min = DBL_MAX;

			//	find the maximum and minimum of the DCT coefficients for scaling
			for (int iter = 0; iter < 15; iter++)
			{
				if (obs->at<double>(iter, i) > max)max = obs->at<double>(iter, i);
				else if (obs->at<double>(iter, i) < min)min = obs->at<double>(iter, i);
			}

			//	rescale each of the DCT coefficients
			for (int iter = 0; iter < 15; iter++)
			{
				obs->at<double>(iter, i) = obs->at<double>(iter, i) / (max - min);
			}
		}
	}

	/*
	*	This is an accessor functions that returns the pointer to the observation matrix stored in heap memory
	*/
	Mat* getObs()
	{
		return obs;
	}

	/*
	*	This function allows the extraction of a single observation at a specified position in the sequence as a column vector
	*	The parameter passed to it must be valid, i.e should be positive and less than the size of the observation sequence
	*/
	NColVector getObs(const int &i)
	{
		//	declare an array of double values to store the observation temporarily
		double* arr = new double[15];

		//	copy the elemetns of the observation at the specified position in the sequence into the array
		for (int j = 0; j < 15; j++)
		{
			arr[j] = obs->at<double>(j, i);
		}

		//	create a new column vector from the array
		NColVector v(15, arr);

		//deallocate memory for the temporary array
		delete[] arr;

		//return the created column vector
		return v;
	}

};
// end of class Obs

/*
*	Overloaded '*' operator for multiplication of a row vector and a matrix of same number of rows as the dimension of the row vector
*	Returns a row vector formed by multiplication of the row vector and matrix
*/
NRowVector operator*(const NRowVector &v1, const Mat &op)
{
	//	check if number of rows of the matrix is same as dimensions of the row vector
	if (op.rows != v1.getSize())
		return NRowVector(v1.getSize());

	//	initialize the number of rows and columns in the product vector
	int r = 1;
	int c = op.cols;

	//	create a product row vector with the required dimensions
	NRowVector prod(c);

	//	create a temporary variable for storing the value of each element of the product matrix
	double tmp;

	//	form the product by iterating over the elements of the row vector and the columns of the matrix
	for (int j = 0; j < c; j++)
	{
		//	set the temporary variable to zero at the beginning of each iteration
		tmp = 0;

		//	iterate over the column elements and form the product element
		for (int k = 0; k < op.rows; k++)
		{
			tmp += v1.getElement(k)*op.at<double>(k, j);
		}

		//	set the product element
		prod.setElement(j, tmp);
	}

	// return the product row vector
	return prod;
}

/*
*	Overloaded '*' operator for multiplication of a matrixa and columnn vector
*	The matrix must have same number of columns as the dimension of the column vector
*	Returns a column vector formed by multiplication of the row vector and matrix
*/
NColVector operator*(const Mat &op, const NColVector &v1)
{
	//	check if number of columns of the matrix is same as dimensions of the columns vector
	if (op.cols != v1.getSize())
		return NColVector(v1.getSize());

	//	initialize the number of rows and columns in the product vector
	int c = 1;
	int r = op.cols;

	//	create a product column vector with the required dimensions
	NColVector prod = NColVector(c);

	//	create a temporary variable for storing the value of each element of the product matrix
	double tmp;

	//	form the product by iterating over the elements of the column vector and the rows of the matrix
	for (int j = 0; j < r; j++)
	{
		//	set the temporary variable to zero at the beginning of each iteration
		tmp = 0;

		//	iterate over the row elements and form the product element
		for (int k = 0; k < op.cols; k++)
		{
			tmp += op.at<double>(j, k)*v1.getElement(k);
		}

		//	set the product element
		prod.setElement(j, tmp);
	}

	// return the product row vector
	return prod;

}

/*
*	This is an overloaded '*' operator for the multiplication of a row vector and a column  vector
*	It is more familiar as the dot product or inner product of two vectors, and returns the double value(dot product)
*/
double operator*(const NRowVector &v1, const NColVector &v2)
{
	//	initialize product to zero
	double prod = 0;

	//	get the size of the smaller of the two vectors, so that we iterate only over those elements
	int t = v1.getSize() < v2.getSize() ? v1.getSize() : v2.getSize();

	//	Multiply each element of the row vector by corresponding element of column vector, as long as elements of both the vectors exist
	for (int j = 0; j < t; j++)
	{
		prod = prod + v1.getElement(j)*v2.getElement(j);
	}

	//return the product
	return prod;
}

/*
*	This is an overloaded '*' operator for the multiplication of a column vector with a row vector, strictly in that order, whose dimensions are the same
*	The prodct is a square matrix with same dmensions as either of the two vectors
*/
Mat operator*(const NColVector &v1, const NRowVector &v2)
{
	//	check if the dimensions of the two vectors are the same, otherwise return a 1x1 matrix
	if (v1.getSize() != v2.getSize())return Mat(1, 1, CV_64F, Scalar(0));

	//	create a product matrix with required dimensions
	Mat prod(v1.getSize(), v2.getSize(), CV_64F, Scalar(0));

	//	compute the elements of the matrix
	for (int i = 0; i < v1.getSize(); i++)
		for (int j = 0; j < v2.getSize(); j++)prod.at<double>(i, j) = v1.getElement(i)*v2.getElement(j);

	//	return the product matrix
	return prod;
}

/*
*	Overloaded '+' operator for adding two column vectors
*	Takes two vectors, add each of their elements
*	If they are of different dimensions, the smaller one is considered to be a deprecated bigger vector with the extra elements zero
*	Hence a column vector with the dimension of the bigger operand is returned
*/
NColVector operator+(const NColVector &v1, const NColVector &v2)
{
	//	get the size of the bigger of the two column vectors
	int s = v1.getSize() > v2.getSize() ? v1.getSize() : v2.getSize();

	//	create a double array for storing the values of the elements of the sum
	double *arr = new double[s];

	//	iterate over the elements and get the sum vector elements
	for (int j = 0; j < s; j++)
	{
		//	set the initial sum to be zero
		arr[j] = 0;

		//	iterate only over those elements whuch are existing, rest are assumed to be zero
		if (v1.getSize() > j)arr[j] += v1.getElement(j);
		if (v2.getSize() > j)arr[j] += v2.getElement(j);
	}

	//	form the sum column vector with the help of the array of values for the sum
	NColVector sum = NColVector(s, arr);

	//	delete the temporary array
	delete[] arr;

	//	return the sum column vector
	return sum;
}

/*
*	Overloaded '+' operator for adding two column vectors
*	Takes two vectors, add each of their elements
*	If they are of different dimensions, the smaller one is considered to be a deprecated bigger vector with the extra elements zero
*	Hence a column vector with the dimension of the bigger operand is returned
*/
NRowVector operator+(const NRowVector &v1, const NRowVector &v2)
{
	//	get the size of the bigger of the two row vectors
	int s = v1.getSize() > v2.getSize() ? v1.getSize() : v2.getSize();

	//	create a double array for storing the values of the elements of the sum
	double *arr = new double[s];

	//	iterate over the elements and get the sum vector elements
	for (int j = 0; j < s; j++)
	{
		//	set the initial sum to be zero
		arr[j] = 0;

		//	iterate only over those elements whuch are existing, rest are assumed to be zero
		if (v1.getSize() < j)arr[j] += v1.getElement(j);
		if (v2.getSize() < j)arr[j] += v2.getElement(j);
	}

	//	form the sum row vector with the help of the array of values for the sum
	NRowVector sum = NRowVector(s, arr);

	//	delete the temporary array
	delete[] arr;

	//	return the sum row vector
	return sum;
}

/*
*	This is an overloaded '*' operator for left multipliccation of a column vector by a constant scalar value.
*	It returns the column vector scaled by the scalar value.
*/
NColVector operator*(const double &d, const NColVector &v)
{
	//declare a column vector object for storing the new scaled vector	
	NColVector v1(v);

	//	scale each element of the vector by the scaling factor
	for (int j = 0; j < v.getSize(); j++)v1.setElement(j, d*v.getElement(j));

	//	return the scaled vector
	return v1;
}

/*
*	This is an overloaded '*' operator for right multipliccation of a column vector by a constant scalar value.
*	It returns the column vector scaled by the scalar value.
*/
NColVector operator*(const NColVector &v, const double &d)
{
	//	declare a column vector object for storing the new scaled vector
	NColVector v1(v);

	//	scale each element of the vector by the scaling factor
	for (int j = 0; j < v.getSize(); j++)v1.setElement(j, d*v.getElement(j));

	//	return the scaled vector
	return v1;
}

/*
*	This is an overloaded '*' operator for left multipliccation of a column vector by a constant scalar value.
*	It returns the column vector scaled by the scalar value.
*/
NRowVector operator*(const double &d, const NRowVector &v)
{
	//	declare a row vector object for storing the new scaled vector
	NRowVector v1(v);

	//	scale each element of the vector by the scaling factor
	for (int j = 0; j < v.getSize(); j++)v1.setElement(j, d*v.getElement(j));

	//	return the scaled vector
	return v1;
}

/*
*	This is an overloaded '*' operator for right multipliccation of a column vector by a constant scalar value.
*	It returns the column vector scaled by the scalar value.
*/
NRowVector operator*(const NRowVector &v, const double &d)
{
	//	declare a row vector object for storing the new scaled vector
	NRowVector v1(v);

	//	scale each element of the vector by the scaling factor
	for (int j = 0; j < v.getSize(); j++)v1.setElement(j, d*v.getElement(j));

	//	return the scaled vector
	return v1;
}

/*
*	Overloaded '-' operator for subtracting a column vector from another
*	Takes two vectors, subtracts each element of the second from the corresponding element of the first
*	If they are of different dimensions, the smaller one is considered to be a deprecated bigger vector with the extra elements zero
*	Hence a column vector with the dimension of the bigger operand is returned
*/
NColVector operator-(NColVector v1, NColVector v2)
{
	//	get the size of the bigger of the two column vectors
	int s = v1.getSize() > v2.getSize() ? v1.getSize() : v2.getSize();

	//	create a double array for storing the values of the elements of the difference
	double *arr = new double[s];

	//	iterate over the elements and get the difference vector elements
	for (int j = 0; j < s; j++)
	{
		//	set the initial difference element to be zero
		arr[j] = 0;

		//	iterate only over those elements whuch are existing, rest are assumed to be zero
		//	add the elements of the first vector and subtract elements of the second
		if (v1.getSize() > j)arr[j] += v1.getElement(j);
		if (v2.getSize() > j)arr[j] -= v2.getElement(j);
	}

	//	form the difference column vector with the help of the array of values for the sum
	NColVector diff(s, arr);

	//	delete the temporary array
	delete[] arr;

	//	return the difference column vector
	return diff;
}
/*
*	Overloaded '-' operator for subtracting a row vector from another
*	Takes two vectors, subtracts each element of the second from the corresponding element of the first
*	If they are of different dimensions, the smaller one is considered to be a deprecated bigger vector with the extra elements zero
*	Hence a row vector with the dimension of the bigger operand is returned
*/
NRowVector operator-(NRowVector v1, NRowVector v2)
{
	//	get the size of the bigger of the two row vectors
	int s = v1.getSize() > v2.getSize() ? v1.getSize() : v2.getSize();

	//	create a double array for storing the values of the elements of the difference
	double *arr = new double[s];

	//	iterate over the elements and get the difference vector elements
	for (int j = 0; j < s; j++)
	{
		//	set the initial difference element to be zero
		arr[j] = 0;

		//	iterate only over those elements whuch are existing, rest are assumed to be zero
		//	add the elements of the first vector and subtract elements of the second
		if (v1.getSize() > j)arr[j] += v1.getElement(j);
		if (v2.getSize() > j)arr[j] -= v2.getElement(j);
	}

	//	form the difference column vector with the help of the array of values for the sum
	NRowVector sum = NRowVector(s, arr);

	//	delete the temporary array
	delete[] arr;

	//	return the difference column vector
	return sum;
}

/*
Overoaded '+=' operator for adding two Mat objects
*/
Mat operator+=(Mat &m1, const Mat &m2)
{
	return (m1 = m1 + m2);

}

/*
*	This function converts a Mat object containing one column into a column vector which is dynamically stored on heap, and a pointer to it is returned
*/
NColVector* convertToColVec(Mat* m)
{
	//	check if th matrix contains only one column, otherwise return a null pointer
	if (m->cols != 1)return NULL;

	// get the size of the column vector indicated by the number of rows in the matrix
	int size = m->rows;

	//create a double array for temporarily storing the values of the elements of the column vector
	double* arr = new double[size];

	// check if a null pointer is returned during allocation, if so, return null pointer
	if (arr == NULL)return NULL;

	//	assign the elements of the vector from the matrix to the array
	for (int j = 0; j < size; j++)
	{
		arr[j] = m->at<double>(j, 0);
	}

	//	create a new NColVector from the array
	NColVector* v = new NColVector(size, arr);

	//	delete the temporary holding array
	delete[] arr;

	//	return the pointer to the column vector
	return v;
}

/*
*	This function converts a Mat object containing one row into a row vector which is dynamically stored on heap, and a pointer to it is returned
*/
NRowVector* convertToRowVec(Mat* m)
{
	//	check if th matrix contains only one column, otherwise return a null pointer
	if (m->rows != 1)return NULL;

	// get the size of the row vector indicated by the number of columns in the matrix
	int size = m->cols;

	//create a double array for temporarily storing the values of the elements of the row vector
	double* arr = new double[size];

	// check if a null pointer is returned during allocation, if so, return null pointer
	if (arr == NULL)return NULL;

	//	assign the elements of the vector from the matrix to the array
	for (int j = 0; j < size; j++)
	{
		arr[j] = m->at<double>(0, j);
	}

	//	create a new NRowVector from the array
	NRowVector* v = new NRowVector(size, arr);

	//	delete the temporary holding array
	delete[] arr;

	//	return the pointer to the row vector
	return v;
}

/*
The following is a class definition.
It implements a multivariate Gaussian(nornmal) probability distribution, with observations in the form of n-dimensional column vectors
*/
class Gaussian
{
	//	member variables

	//	stores the mean of the observations, it is a colun vector in n-space
	NColVector mean;

	//	the covariance matrix plays the multidimensional role of the variance matrix in one dimension
	Mat var;
public:
	//	public section

	/*
	*	Default constructor for the class
	*	It initializes mean to zero and variance to one
	*/
	Gaussian()
	{
		mean = 0;
		var = 1;
	}

	/*
	Overloaded parametrized constructor for the class
	It takes as it parameters the mean and variance of the distribution which completely specifies the probability distribution
	*/
	Gaussian(const NColVector &mu, const Mat &sigma)
	{
		mean = mu;
		var = sigma.clone();
	}

	/*
	*	Accessor function for getting the mean of the distribution
	*/
	NColVector getMean() const
	{
		return mean;
	}

	/*
	*	Accessor function for getting the covariance matrix of the distribution
	*/
	Mat getVar() const
	{
		return var;
	}

	/*
	*	Mutator function for setting the mean of the distribution
	*/
	void setMean(const NColVector &mu)
	{
		mean = mu;
	}

	/*
	*	Mutator function for setting the covariance matrix of the distribution
	*/
	void setVar(const Mat &sigma)
	{
		var = sigma;
	}

	/*
	*	This function returns the probability of an observation vector given the Gaussian distribution
	*/
	double getProb(NColVector x)
	{
		/*double dtmp[15][15], l[15][15], u[15][15], idtmp[15][15];
		for (int i = 0; i<var.rows; i++)
		{
		for (int j = 0; j<var.cols; j++)
		{
		dtmp[i][j] = 10000000000.0*var.at<double>(i, j);
		idtmp[i][j] = var.at<double>(i, j);
		}
		}
		double det = Determinant(dtmp, l, u, 15);
		if (fabs(det) < EPSILON)
		return 1;*/
		Mat singu, uu, vt;
		SVD::compute(var, singu, uu, vt);
		double det = 1.0;
		for (int i = 0; i < singu.rows; i++)
			for (int j = 0; j < singu.cols; j++)
				det *= (uu.at<double>(i, j) == 0) ? 1 : uu.at<double>(i, j);
		//Invert(idtmp, 15);
		Mat inv_covar(15, 15, CV_64F);
		if (!invert(var, inv_covar, DECOMP_SVD))
		{
			cout << "inverse failed" << endl;
		}
		//for (int i = 0; i<var.rows; i++)
		//{
		//for (int j = 0; j<var.cols; j++)
		//{
		//inv_covar.at<double>(i, j) = idtmp[i][j];
		//}
		//
		//}
		////invert(var,inv_covar);
		//cout << x.convertToMat() << endl;
		//cout << mean.convertToMat() << endl;
		NColVector mean_ = x - mean;
		//for (int iter = 0; iter < 15; iter++)cout << mean_.getElement(iter)<<" ";
		NRowVector mean_t = (x - mean).transpose();
		//for (int iter = 0; iter < 15; iter++)cout << mean_.getElement(iter) << " ";
		NRowVector rhs = mean_t*inv_covar;
		//for (int iter = 0; iter < 15; iter++)cout << rhs.getElement(iter) << " ";
		double index = rhs*(x - mean);
		//cout << "Index:" << index << endl;
		double num = exp(-(index) / 2);
		double den = sqrt(pow(2 * PI, var.rows)*fabs(det));
		double p = (num) / den;
		if (p>1){
			cout << "Error in probability calculation ... " << endl;
			return num / den;
		}
		return  p;
	}

	/*
	*	Copy constructor for the Gaussian class
	*/
	Gaussian(const Gaussian &g)
	{
		mean = g.getMean();
		var = g.getVar().clone();
	}
	/*
	*	Overloaded '=' operator for the class
	*/
	Gaussian operator=(const Gaussian &g)
	{
		mean = g.getMean();
		var = g.getVar().clone();
		return *this;
	}
	/*
	*	Destructor for the Gaussian
	*/
	~Gaussian()
	{
	}
};


/*
*	The following is a class definition.
*	The HMM class implements a Hidden markov Model with continuous emission probabilities, with the observations being 15 dimensional vectors consisting of DCT coefficients for
*	images of a test subject for the purpose of face recognition
*/
class HMM
{
	//	member variables

	//	stores an array of observation sequences, one for each face being trained for the test subject
	Obs* SEQ;

	//	stores the transition probabilities
	Mat* TRANS;

	//	stores the initial probabilities
	Mat* INIT;

	//	stores an array of Gaussian means, one for each combination of mixture and state
	NColVector **GAUSS_MEAN;

	//	stores an array of Gaussian covariance matrices, one for each combination of mixture and state 
	Mat **GAUSS_VAR;

	//	stores an array of Gaussian mixture probabilities, one for each combination of mixture and state 
	double** GAUSS_PROB;

	//	stores number of faces
	int faces;

	//	stores the total number of observations for each observation sequence
	int n_obs;

	//	stores the number of states
	int states;

	//	stores the number of mixtures in the Gaussian distribution model being implemented
	int mixtures;

	//	stores the Gaussian probability distributions, one for each combination of state and mixture
	Gaussian** GAUSS;
public:
	//	public section

	/*
	This function writes the parameters that define the HMM to a file, whose name it takes as a parameter
	*/
	int write(string outfilename)
	{
		//	stream for writing the HMM parameters to a YAML file
		FileStorage fs(outfilename.c_str(), FileStorage::WRITE);

		// check if file stream has opened properly
		if (!fs.isOpened())return -1;

		// write the necessary parameters to characterise the HMM

		//	write number of states
		fs << "n_states" << states;

		//	write number of mixtures
		fs << "n_mixtures" << mixtures;

		//	write transition probabilities
		fs << "trans" << *TRANS;

		//	write initial probabilities
		fs << "init" << *INIT;

		//	write array of Gaussian means
		for (int i = 0; i<states; i++)
			for (int j = 0; j<mixtures; j++)
			{
			Mat tmp = GAUSS_MEAN[i][j].convertToMat();
			stringstream tt;
			tt << "mean_" << i << "_" << j;
			fs << tt.str() << tmp;
			}

		//	write array of Gaussian covariance matrices
		for (int i = 0; i<states; i++)
			for (int j = 0; j<mixtures; j++)
			{
			stringstream tt;
			tt << "var_" << (i) << "_" << (j);
			fs << tt.str() << GAUSS_VAR[i][j];
			}

		//	write array of Gaussian mixture probabilities
		for (int i = 0; i<states; i++)
			for (int j = 0; j<mixtures; j++)
			{
			stringstream tt;
			tt << "prob_" << (i) << "_" << (j);
			fs << tt.str() << GAUSS_PROB[i][j];
			}

		//	close file stream
		fs.release();
	}

	/*
	*	The function reads the HMM parameters stored in a file whose path is passed as a parameter,
	*	then it computes the maximum likelihood for a test image whose path is specified as the second parameter
	*/
	void read(string infilename, string testImageFile)
	{
		//	create file stream for reading the parameters of HMM from a file
		FileStorage fs(infilename.c_str(), FileStorage::READ);

		//	read the parameters and store them in the member variables
		fs["n_states"] >> states;
		fs["n_mixtures"] >> mixtures;
		fs["trans"] >> *TRANS;
		fs["init"] >> *INIT;
		for (int i = 0; i<states; i++)
			for (int j = 0; j<mixtures; j++)
			{
			stringstream tt;
			tt << "var_" << (i) << "_" << (j);
			fs[tt.str()] >> GAUSS_VAR[i][j];
			}
		for (int i = 0; i<states; i++)
			for (int j = 0; j<mixtures; j++)
			{
			stringstream tt;
			tt << "prob_" << (i) << "_" << (j);
			fs[tt.str()] >> GAUSS_PROB[i][j];
			}
		for (int i = 0; i<states; i++)
			for (int j = 0; j<mixtures; j++)
			{
			Mat tmp;
			stringstream tt;
			tt << "mean_" << (i) << "_" << (j);
			fs[tt.str()] >> tmp;
			GAUSS_MEAN[i][j] = *convertToColVec(&tmp);
			}

		// close the file stream
		fs.release();

		//	read the test image whose path is specified as the second parameter
		Mat image;
		image = cv::imread(testImageFile, CV_LOAD_IMAGE_GRAYSCALE);

		//	check if image was read correctly
		if (!image.data)
		{
			cout << "Could not read image. Error ..." << endl;
			return;
		}

		//check if image size matches with definition
		if (image.rows != IMG_ROW || image.cols != IMG_COL)
			cv::resize(image, image, cv::Size2d(IMG_ROW, IMG_COL));

		//	extract the DCT coefficients of the image

		//an array to store the partial DCT coefficients 
		double tmp[SW_SIZE][SW_SIZE];

		//	for loop to iterate over the DCT matrices, each of which is a part of a matrix itself of DCT_NUM1*DCT_NUM2 elements
		for (int i = 0; i < DCT_NUM1; i++)
		{

			//	for loop to iterate over the DCT matrices, each of which is a part of a matrix itself of DCT_NUM1*DCT_NUM2 elements
			for (int j = 0; j < DCT_NUM2; j++)
			{

				//	the number in which order this DCT matrix will appear in the matrix of DCT matrices
				int num = DCT_NUM1 * i + j;

				//	the starting point(row) of the sliding window in the image 
				int start_row = APP_SIZE * i;

				//	the starting point(column) of the sliding window in the image
				int start_col = APP_SIZE * j;

				//	the opposite corner of sliding window(row) in image
				int end_row = start_row + SW_SIZE;

				//	the opposite corner of sliding window (column) in image
				int end_col = start_col + SW_SIZE;

				//	coefficient to be multiplied with cosine terms
				double alpha;
				for (int u = 0; u < SW_SIZE; u++)
				{
					for (int v = 0; v < SW_SIZE; v++)
					{
						tmp[u][v] = 0;
						alpha = (v != 0) ? 1 : INVSQRT2;
						for (int x = start_col, y = start_row + u; x < end_col; x++)
							tmp[u][v] += (alpha*cos(PI *(2 * x + 1)*v / (2 * SW_SIZE))*((int)image.at<uchar>(y, x)));
					}
				}
				for (int u = 0; u<SW_SIZE; u++)
				{
					for (int v = 0; v<SW_SIZE; v++)
					{
						DCT[num][u][v] = 0.0;
						alpha = (v != 0) ? 1 : INVSQRT2;
						for (int y = 0, x = u; y < SW_SIZE; y++)
							DCT[num][u][v] += (alpha*cos(PI *(2 * y + 1)*u / (2 * SW_SIZE))*(tmp[y][x]));
						DCT[num][u][v] = DCT[num][u][v] / (SW_SIZE*SW_SIZE);
					}
				}
			}
		}

		//store observation sequence
		O[0] = Obs(DCT, DCT_NUM1*DCT_NUM2);
		SEQ = O;
		faces = 1;
		n_obs = DCT_NUM1*DCT_NUM2;
		GAUSS = new Gaussian*[states];
		for (int i = 0; i<states; i++)
		{
			GAUSS[i] = new Gaussian[mixtures];
			for (int j = 0; j<mixtures; j++)
			{
				GAUSS[i][j] = Gaussian(GAUSS_MEAN[i][j], GAUSS_VAR[i][j]);
			}
		}

		//	find and print negative log of likelihood of the given test image with given HMM
		cout << getMaxLikelihood(O[0], *TRANS, *INIT, GAUSS, GAUSS_PROB, states, mixtures) << endl;
	}

	/*
	*	Constructor for the HMM class which takes as its parameters the observation sequence, number of faces, number of observations, number of states and number of mixtures
	*/
	HMM(Obs* O, int num_faces, int num_obs, int num_states, int num_mixtures)
	{
		SEQ = O;
		faces = num_faces;
		n_obs = num_obs;
		states = num_states;
		mixtures = num_mixtures;

		//	Initialzing initial probabilities, transition probabilities and Gaussian parameters with default values
		INIT_TRANS();
		INIT_INIT();
		INIT_GAUSSIAN();
	}

	/*
	*	Constructor for the HMM class which takes as its parameters the number of faces, number of observations in each observation sequence, number of states and number of mixtures
	*	Since no observation is taken as parameter, SEQ is set to NULL
	*	This will be useful for constricting HMMs only to get likelihood
	*/
	HMM(int num_faces, int num_obs, int num_states, int num_mixtures)
	{
		SEQ = NULL;
		faces = num_faces;
		n_obs = num_obs;
		states = num_states;
		mixtures = num_mixtures;
		INIT_TRANS();
		INIT_INIT();
		INIT_GAUSSIAN();
	}

	/*
	*	Overloaded parametrized constructor for HMM class that only takes number of states as a parameter
	*	Number of states must be positive
	*/
	HMM(int s)
	{
		SEQ = NULL;
		faces = 1;
		n_obs = 0;
		states = s;
		mixtures = 1;
		INIT_TRANS();
		INIT_INIT();
		INIT_GAUSSIAN();
	}

	/*
	*	Default mutator function for setting the observation sequence with default number of faces 1
	*/
	void setObs(Obs *O)
	{
		SEQ = O;
		cout << "Declaring Gaussian matrices..." << endl;
		faces = 1;
	}

	/*
	*	Mutator function for setting the observation sequence, taking number of faces as parameter.
	*	Number of faces must be non-negative
	*/
	void setObs(Obs *o, int num_faces)
	{
		SEQ = o;
		faces = num_faces;
	}

	/*
	*	Accessor function which returns number of states
	*/
	int getStates()
	{
		return states;
	}

	/*
	*	Accessor function which returns number of mixtures
	*/
	int getMixtures()
	{
		return mixtures;
	}

	/*
	*	Accessor function which returns number of observations in each observation sequence
	*/
	int getNObs()
	{
		return n_obs;
	}

	/*
	*	Accessor function which returns number of faces being trained for the test subject
	*/
	int getFaces()
	{
		return faces;
	}

	/*
	*	This function initialises the transition probability matrix with random initial values.
	*	This is the default initialization.
	*/
	void INIT_TRANS()
	{
		//	Allocate memory on heap for transition probability matrix
		TRANS = new Mat(states, states, CV_64F, Scalar(((double)(1.0)) / states));

		//	Iterate over the whole matrix and initializeach element wwith random values
		for (int i = 0; i<TRANS->rows; i++)
			for (int j = 0; j<TRANS->cols; j++)
				TRANS->at<double>(i, j) = (rand() % 10000) / 10000.0;

		//	Since the transition probability matrix has to follow the constaint that the sum of transition probabilities from one state to all other states must be 1, the matrix must be normalized

		//	in the matrix, the element in i th row and j th column denotes the probability of transition from state i to state j
		//	so the sum of elements in each row must be 1
		//  declare a temporary variable to hold the sum of the elements in each row
		double sum;

		//	iterate over all rows
		for (int i = 0; i<TRANS->rows; i++)
		{
			//	initialize sum to zero at beginning of each iteration
			sum = 0;

			//	find sum of elements in each row
			for (int j = 0; j<TRANS->cols; j++)
				sum += TRANS->at<double>(i, j);

			//	rescale each row so that the sum is 1
			for (int j = 0; j<TRANS->cols; j++)
				TRANS->at<double>(i, j) /= sum;
		}
	}

	/*
	*	This function initialises the Gaussian parameters with initial values.
	*	This is the default initialization.
	*/
	void INIT_GAUSSIAN()
	{
		GAUSS = new Gaussian*[states];
		GAUSS_MEAN = new NColVector*[states];
		GAUSS_VAR = new Mat*[states];
		GAUSS_PROB = new double*[states];
		if (GAUSS == NULL) { cout << "Problem" << endl; return; }
		for (int j = 0; j < states; j++)
		{
			GAUSS[j] = new Gaussian[mixtures];
			GAUSS_MEAN[j] = new NColVector[mixtures];
			GAUSS_VAR[j] = new Mat[mixtures];
			GAUSS_PROB[j] = new double[mixtures];
			if (GAUSS[j] == NULL) { cout << "Problem" << endl; return; }
			for (int k = 0; k < mixtures; k++)
			{
				GAUSS_MEAN[j][k] = NColVector(15, 1);
				for (int iter = 0; iter < 15; iter++)GAUSS_MEAN[j][k].setElement(iter, (rand() % 10000) / 10000.0);
				GAUSS_PROB[j][k] = 1.0 / mixtures;
				GAUSS_VAR[j][k] = Mat(15, 15, CV_64F, Scalar(1));
				for (int r = 0; r < 15; r++)
					for (int c = 0; c < 15; c++)if (r != c)GAUSS_VAR[j][k].at<double>(r, c) = 0;
				GAUSS[j][k] = Gaussian(GAUSS_MEAN[j][k], GAUSS_VAR[j][k]);
			}

		}
	}
	void INIT_GAUSSIAN2()
	{
		GAUSS = new Gaussian*[states];
		GAUSS_MEAN = new NColVector*[states];
		GAUSS_VAR = new Mat*[states];
		GAUSS_PROB = new double*[states];
		if (GAUSS == NULL) { cout << "Problem" << endl; return; }
		int part = n_obs / mixtures;
		NColVector* sum = new NColVector[mixtures];
		Mat *obsClust = new Mat[mixtures];
		for (int i = 0; i < mixtures; i++)sum[i] = NColVector(15, 0.0);
		for (int j = 0; j < mixtures; j++)
		{
			obsClust[j] = Mat(15, part*faces, CV_64F);
			for (int i = 0; i < faces; i++)
			{
				for (int k = j*mixtures, count = 0; count < part; k++, count++)
				{
					sum[j] = sum[j] + SEQ[i].getObs(k);
					(obsClust[j]).col(part*i + k) = SEQ[i].getObs()->col(k);
				}

			}
			sum[j] = sum[j] * (1 / (faces*part));
		}
		for (int j = 0; j < states; j++)
		{
			GAUSS[j] = new Gaussian[mixtures];
			GAUSS_MEAN[j] = new NColVector[mixtures];
			GAUSS_VAR[j] = new Mat[mixtures];
			GAUSS_PROB[j] = new double[mixtures];
			if (GAUSS[j] == NULL) { cout << "Problem" << endl; return; }
			for (int k = 0; k < mixtures; k++)
			{
				GAUSS_MEAN[j][k] = NColVector(sum[j]);
				GAUSS_PROB[j][k] = 1.0 / mixtures;
				Mat covar(15, 15, CV_64F);
				Mat mean(15, 1, CV_64F, Scalar(0));
				calcCovarMatrix(obsClust[k], covar, mean, CV_COVAR_COLS);
				GAUSS_VAR[j][k] = Mat(covar);
				GAUSS[j][k].setMean(GAUSS_MEAN[j][k]);
				GAUSS[j][k].setVar(GAUSS_VAR[j][k]);
			}

		}
		delete[] sum;
		delete[] obsClust;
	}

	/*
	*	This function initialises the initial probability matrix with random initial values.
	*	This is the default initialization.
	*/
	void INIT_INIT()
	{
		//	allocate memory on the heap for the initial probability matrix
		INIT = new Mat(1, states, CV_64F, Scalar(0));

		//	initialize the matrix with random values
		for (int i = 0; i<INIT->rows; i++)
			for (int j = 0; j<INIT->cols; j++)
				INIT->at<double>(i, j) = (rand() % 10000) / 10000.0;

		//	since sum of initial probabilities must add up to 1, the matrix has to be rescaled
		//	temporary variable to stoe sum of initial probabilities
		double sum;
		for (int i = 0; i<INIT->rows; i++)
		{
			// initialize sum to zero at the beginning of each iteration
			sum = 0;

			//	find the sum of initial probabilities
			for (int j = 0; j<INIT->cols; j++)
				sum += INIT->at<double>(i, j);

			//	rescale the matrix by dividing with the sum so that the probabilities add up to 1
			for (int j = 0; j<INIT->cols; j++)
				INIT->at<double>(i, j) /= sum;
		}

	}

	/*
	*	This function takes as input pointer to a  matrix that has to row normalized and rescales the matrix,
	*	also replacing values below a certain threshold with a default small value
	*/
	void correct(Mat* m)
	{
		//	declare a temporary variable for storing the sum of elements along a row
		double sum = 0;

		//	iterate over the rows
		for (int j = 0; j < m->rows; j++)
		{
			// initialize sum with zero at the beginning of each iteration
			sum = 0;

			//	find the sum of elements in each row
			for (int k = 0; k < m->cols; k++)
			{
				// if any element is less than the threshold value, replace it with the threshold value
				if (m->at<double>(j, k) < EPSILON)m->at<double>(j, k) = EPSILON;

				sum += m->at<double>(j, k);
			}

			// rescale the row so that sum of elements along each row is 1
			for (int k = 0; k < m->cols; k++) m->at<double>(j, k) /= sum;
		}
	}

	/*
	*	Function for calculating minimum negative logarithm of likelihood of observation sequence given as parameter, also given parameters of the HMM as parameters
	*	Since this is astatic function it can be called without creating an object of the class
	*/
	static double getMaxLikelihood(Obs &o, Mat &trans, Mat &init, Gaussian **g, double **gauss_prob, int nstates, int nmix)
	{
		// the likelihood is calculated recursively using Viterbi algorithm

		//DELTA matrix progressively stores the probabilities of the state sequences(their negative logarithms, actually)
		Mat DELTA(nstates, o.getObs()->cols, CV_64F, Scalar(0));

		//SIGMA matrix stores the path of states followed to reach a particular maximum likelihood observation
		Mat SIGMA(nstates, o.getObs()->cols, CV_32S, Scalar(0));

		//variables to store proability and the function to minimize(negative logarithm of likelihood) which is equivalen to maximizing likelihood
		double prob = 0;
		double fnToMin;
		NColVector *tmp = NULL;
		for (int j = 0; j < nstates; j++)
		{
			//	storing the observation as a column vector
			tmp = new NColVector(o.getObs(0));

			//	checking for null pointer
			if (tmp == NULL)
			{
				cout << "Error in initializing col vector ..." << endl;
				return 0;
			}

			// initialising emission probability to zero
			double emis_prob = 0;

			for (int m = 0; m < nmix; m++)emis_prob += gauss_prob[j][m] * g[j][m].getProb(*tmp);
			DELTA.at<double>(j, 0) = init.at<double>(0, j)*emis_prob;
		}

		//	finding minimum negative logarithm of likelihood
		for (int t = 1; t < o.getObs()->cols; t++)
		{
			for (int j = 0; j < nstates; j++)
			{
				fnToMin = -log(DELTA.at<double>(0, t - 1)) - log(trans.at<double>(0, j));
				SIGMA.at<int>(j, t) = 0;
				tmp = new NColVector(o.getObs(t));
				if (tmp == NULL)
				{
					cout << "Error in initializing col vector ..." << endl;
					return -1;
				}
				double emis_prob = 0;
				for (int m = 0; m < nmix; m++)emis_prob += gauss_prob[j][m] * g[j][m].getProb(*tmp);
				delete tmp;
				tmp = NULL;
				DELTA.at<double>(j, t) = (fnToMin)-log(emis_prob);
				for (int k = 1; k < nstates; k++)
				{
					double temp = -log(DELTA.at<double>(0, t - 1)) - log(trans.at<double>(0, j));
					if (temp < fnToMin)
					{
						SIGMA.at<int>(j, t) = k;
						tmp = new NColVector(o.getObs(t));
						if (tmp == NULL)
						{
							cout << "Error in initializing col vector ..." << endl;
							return 0;
						}
						double emis_prob = 0;
						for (int m = 0; m < nmix; m++)emis_prob += gauss_prob[j][m] * g[j][m].getProb(*tmp);
						delete tmp;
						tmp = NULL;
						DELTA.at<double>(j, t) = -log(temp) - log(emis_prob);
						fnToMin = temp;
					}
				}
			}
		}
		int n_obs = o.getObs()->cols;
		int *path_states = new int[n_obs];

		//	recursively compute the most likely sequence of latent states
		path_states[n_obs - 1] = 0;
		for (int j = 1; j < nstates; j++)
			if (DELTA.at<double>(j, n_obs - 1) - DELTA.at<double>(path_states[n_obs - 1], n_obs - 1) > EPSILON)
				path_states[n_obs - 1] = j;
		for (int t = n_obs - 2; t >= 0; t--)path_states[t] = SIGMA.at<int>(path_states[t + 1], t + 1);

		//	computing the negative logarithm of likelihood of the observation sequence by following most likely path of states 
		prob += (DELTA.at<double>(path_states[n_obs - 1], n_obs - 1));
		return prob;
	}

	/*
	*	This function gives the maximum likelihood of the observation sequence used for training given the HMM model using Viterbi algorithm
	*/
	double ViterbiLikelihood()
	{
		Mat DELTA(states, n_obs, CV_64F, Scalar(0));
		Mat SIGMA(states, n_obs, CV_32S, Scalar(0));
		double prob = 0;
		double fnToMax;
		for (int countf = 0; countf < faces; countf++)
		{
			NColVector *tmp = NULL;
			for (int j = 0; j < states; j++)
			{
				tmp = new NColVector(SEQ[countf].getObs(0));
				if (tmp == NULL)
				{
					cout << "Error in initialuzing col vector ..." << endl;
					return 0;
				}
				double emis_prob = 0;
				for (int m = 0; m < mixtures; m++)emis_prob += GAUSS_PROB[j][m] * GAUSS[j][m].getProb(*tmp);
				DELTA.at<double>(j, 0) = INIT->at<double>(0, j)*emis_prob;
			}
			for (int t = 1; t < n_obs; t++)
			{
				for (int j = 0; j < states; j++)
				{
					fnToMax = DELTA.at<double>(0, t - 1)*TRANS->at<double>(0, j);
					SIGMA.at<int>(j, t) = 0;
					tmp = new NColVector(SEQ[countf].getObs(t));
					if (tmp == NULL)
					{
						cout << "Error in initializing col vector ..." << endl;
						return 0;
					}
					double emis_prob = 0;
					for (int m = 0; m < mixtures; m++)emis_prob += GAUSS_PROB[j][m] * GAUSS[j][m].getProb(*tmp);
					delete tmp;
					tmp = NULL;
					DELTA.at<double>(j, t) = fnToMax*emis_prob;
					for (int k = 1; k < states; k++)
					{
						double temp = DELTA.at<double>(0, t - 1)*TRANS->at<double>(0, j);
						if (temp < fnToMax)
						{
							SIGMA.at<int>(j, t) = k;
							tmp = new NColVector(SEQ[countf].getObs(t));
							if (tmp == NULL)
							{
								cout << "Error in initializing col vector ..." << endl;
								return 0;
							}
							double emis_prob = 0;
							for (int m = 0; m < mixtures; m++)emis_prob += GAUSS_PROB[j][m] * GAUSS[j][m].getProb(*tmp);
							delete tmp;
							tmp = NULL;
							DELTA.at<double>(j, t) = temp*emis_prob;
							fnToMax = temp;
						}
					}
				}
			}

			int *path_states = new int[n_obs];
			path_states[n_obs - 1] = 0;
			for (int j = 1; j < states; j++)
				if (DELTA.at<double>(j, n_obs - 1) - DELTA.at<double>(path_states[n_obs - 1], n_obs - 1) > EPSILON)
					path_states[n_obs - 1] = j;
			for (int t = n_obs - 2; t >= 0; t--)path_states[t] = SIGMA.at<int>(path_states[t + 1], t + 1);
			prob += (DELTA.at<double>(path_states[n_obs - 1], n_obs - 1));

		}
		prob = prob / faces;
		return prob;
	}

	/*
	*	This function trains the HMM with the provided observation sequences
	*	It uses the Baum Welch Expectation-Maximization algorithm(E-M algorithm) to train the model
	*	It takes as parameters the threshold for convergence of training and the maximum number of iterations for which the algorithm runs
	*	The algorithm iterates until it converges within given threshold or the number of itwrations exceeds the maximum number of iterations allowed
	*	It returns whether the model was traind successfully
	*/
	int train(double probLimit, int maxCount)
	{

		cout << "Beginning training..." << endl;

		// declaring the function's its versions of the HMM parameters

		//	array of Gaussian covariance matrices
		Mat** GAUSS_VAR_;

		//	array of Gauusian means
		NColVector** GAUSS_MEAN_;

		//	array of Gaussian mixture probabilities
		double** GAUSS_PROB_;

		//	initializing the pointers so that they point to two dimensional arrays
		GAUSS_VAR_ = new Mat*[states];
		if (GAUSS_VAR_ == NULL)
		{
			cout << "Error in initializing pointer." << endl;
			return -1;
		}

		GAUSS_MEAN_ = new NColVector*[states];
		if (GAUSS_MEAN_ == NULL)
		{
			cout << "Error in initializing pointer." << endl;
			return -1;
		}

		GAUSS_PROB_ = new double*[states];
		if (GAUSS_PROB_ == NULL)
		{
			cout << "Error in initializing pointer." << endl;
			return -1;
		}

		for (int i = 0; i < states; i++)
		{
			GAUSS_PROB_[i] = new double[mixtures];
			if (GAUSS_PROB_[i] == NULL)
			{
				cout << "Error in initializing pointer." << endl;
				return -1;
			}

			GAUSS_MEAN_[i] = new NColVector[mixtures];
			if (GAUSS_MEAN_[i] == NULL)
			{
				cout << "Error in initializing pointer." << endl;
				return -1;
			}

			GAUSS_VAR_[i] = new Mat[mixtures];
			if (GAUSS_VAR_[i] == NULL)
			{
				cout << "Error in initializing pointer." << endl;
				return -1;
			}

			//	initializing them with the current Gaussian parameters in main class
			for (int j = 0; j < mixtures; j++)
			{
				GAUSS_PROB_[i][j] = GAUSS_PROB[i][j];
				GAUSS_MEAN_[i][j] = GAUSS_MEAN[i][j];
				GAUSS_VAR_[i][j] = GAUSS_VAR[i][j];
			}
		}

		//	transition probability matrix
		Mat TRANS_ = TRANS->clone();

		//	initial probability matrix
		Mat INIT_ = INIT->clone();

		//	number of observations in each observation sequence
		int T = getNObs();

		// number of states=TRANS.rows=TRANS.cols
		int N = TRANS->rows;

		//	number of mixtures in the Gaussian
		int M = mixtures;

		//	number of iterations of the Baum Welch training algorithm
		int count = 0;

		//	counter for iteration over the faces
		int countf = 0;

		//	declare pointers to matrices for storing the forward, backward and intermediate variables
		Mat *ALPHA = NULL;;
		Mat *BETA = NULL;
		Mat *GAMMA = NULL;

		//	declare a variable for holding the emission probability, that is the probability of an observation with respect to a Gaussian distribution
		double emis_prob;

		//	a temporary column vector for storing the observation
		NColVector* tmp;

		//	variables for storing the old and new negative logarithm of probability/likelihoods
		double *logProb, *newLogProb;

		//	initialize the pointers
		logProb = new double[faces];
		newLogProb = new double[faces];
		for (int j = 0; j < faces; j++)
		{
			logProb[j] = 0;
			newLogProb[j] = 0;
		}

		//	variable for storing difference in the logarithms of probabilities
		double* diffLogProb = new double[faces];
		if (diffLogProb == NULL)
		{
			cout << "Error in initializing pointer." << endl;
			return -1;
		}

		//	column vector for storing the difference in log likelihoods for different faces
		NColVector probLogDiff;

		//the variables prefixed with num_ and den_ are for storing the numerator and denominator total of the updates for all faces so that updating can take place in the last step
		Mat num_TRANS = Mat::zeros(TRANS->rows, TRANS->cols, CV_64F);
		Mat num_INIT = Mat::zeros(INIT->rows, INIT->cols, CV_64F);
		NColVector **num_GAUSS_MEAN;
		Mat** num_GAUSS_VAR;
		double **num_GAUSS_PROB, **den_GAUSS_PROB, **den_GAUSS_MEAN, **den_GAUSS_VAR;

		//	Initializing the pointers and matrices for storing the numerators and denominator of the updates

		//	Initializing the matrices with zeroes
		Mat den_TRANS = Mat::zeros(TRANS->rows, TRANS->cols, CV_64F);
		Mat den_INIT = Mat::zeros(INIT->rows, INIT->cols, CV_64F);

		// Initializing the pointers, check for null pointers
		num_GAUSS_PROB = new double*[states];
		if (num_GAUSS_PROB == NULL)
		{
			cout << "Error in initializing pointer." << endl;
			return -1;
		}

		num_GAUSS_MEAN = new NColVector*[states];
		if (num_GAUSS_MEAN == NULL)
		{
			cout << "Error in initializing pointer." << endl;
			return -1;
		}

		num_GAUSS_VAR = new Mat*[states];
		if (num_GAUSS_VAR == NULL)
		{
			cout << "Error in initializing pointer." << endl;
			return -1;
		}

		den_GAUSS_PROB = new double*[states];
		if (den_GAUSS_PROB == NULL)
		{
			cout << "Error in initializing pointer." << endl;
			return -1;
		}

		den_GAUSS_MEAN = new double*[states];
		if (den_GAUSS_MEAN == NULL)
		{
			cout << "Error in initializing pointer." << endl;
			return -1;
		}

		den_GAUSS_VAR = new double*[states];
		if (den_GAUSS_VAR == NULL)
		{
			cout << "Error in initializing pointer." << endl;
			return -1;
		}

		// Initializing the arrrays with zero values
		for (int i = 0; i < states; i++)
		{
			num_GAUSS_PROB[i] = new double[mixtures];
			num_GAUSS_MEAN[i] = new NColVector[mixtures];
			num_GAUSS_VAR[i] = new Mat[mixtures];
			den_GAUSS_PROB[i] = new double[mixtures];
			den_GAUSS_MEAN[i] = new double[mixtures];
			den_GAUSS_VAR[i] = new double[mixtures];
			for (int j = 0; j < mixtures; j++)
			{
				num_GAUSS_PROB[i][j] = 0;
				num_GAUSS_MEAN[i][j] = NColVector(0 * GAUSS_MEAN[i][j]);
				num_GAUSS_VAR[i][j] = Mat::zeros(15, 15, CV_64F);
				den_GAUSS_PROB[i][j] = 0;
				den_GAUSS_MEAN[i][j] = 0;
				den_GAUSS_VAR[i][j] = 0;
			}
		}

		// start the Baum-Welch algorithm for training the model
		do{
			for (countf = 0; countf < faces; countf++)
			{
				//	at the starting of iterations for each face, deallocate memory for the previous versions of ALPHA,BETA and GAMMA
				//	do not perform this step at the very beginning for they have not been used yet
				if (countf != 0)
				{
					delete ALPHA;
					delete BETA;
					delete GAMMA;
					ALPHA = NULL;
					BETA = NULL;
					GAMMA = NULL;
				}

				//	allocate new memory for ALPHA, BETA and GAMMA
				ALPHA = new Mat(N, T, CV_64F, Scalar(0));
				BETA = new Mat(N, T, CV_64F, Scalar(0));
				GAMMA = new Mat(N, T, CV_64F, Scalar(0));

				//	check for null pointers
				if (ALPHA == NULL || BETA == NULL || GAMMA == NULL)
				{
					cout << "Null pointer returned during initialization of HMM variables." << endl;
					return -1;
				}

				//	define a matrix for storing scaling values for the forward and backward variables
				Mat rf = Mat::zeros(T, 1, CV_64F);

				//	Computing forward variables ALPHA

				//	The initial setting for ALPHA, for initial observation sequence
				for (int i = 0; i < N; i++)
				{
					//	Store the observation as a column vector
					tmp = new NColVector(SEQ[countf].getObs(0));

					// check for null pointer
					if (tmp == NULL)
					{
						cout << "Null pointer returned during initialization of NCOlVector." << endl;
						return -1;
					}

					//	initialize emission probability to zero
					emis_prob = 0.0;

					//	compute emission probability by summing over all mixtures
					for (int countk = 0; countk < M; countk++)
					{
						emis_prob += GAUSS_PROB_[i][countk] * (GAUSS[i][countk].getProb(*tmp));
					}

					//	deallocate memory for the temporary column vector
					delete tmp;
					tmp = NULL;

					//	initialize the forward variable at t=0
					ALPHA->at<double>(i, 0) = INIT_.at<double>(0, i)*emis_prob;

					//	compute the scaling factor
					rf.at<double>(0, 0) += ALPHA->at<double>(i, 0);
				}

				//	divide by scaling factor;
				for (int i = 0; i< N; i++)
					ALPHA->at<double>(i, 0) /= rf.at<double>(0, 0);

				// recursive definition of ALPHA for t=1 to t=T-1
				for (int j = 1; j < T; j++)
				{
					for (int i = 0; i < N; i++)
					{
						//	temporary variable for storing sum over states
						double temp = 0;
						for (int k = 0; k < N; k++)
						{
							temp += ALPHA->at<double>(k, j - 1)*TRANS_.at<double>(k, i);
						}
						if (temp < EPSILON)temp = EPSILON;

						//	Store the observation as a column vector
						tmp = new NColVector(SEQ[countf].getObs(j));

						// check for null pointer
						if (tmp == NULL)
						{
							cout << "Null pointer returned during initialization of NCOlVector." << endl;
							return;
						}

						//	initialize emission probability to zero
						emis_prob = 0.0;

						//	compute emission probability by summing over all mixtures
						for (int countk = 0; countk < M; countk++)emis_prob += GAUSS_PROB_[i][countk] * GAUSS[i][countk].getProb(*tmp);

						//	deallocate memory for the temporary column vector
						delete tmp;
						tmp = NULL;

						// correct for emission probabilities if they fall below a certain threshold
						if (emis_prob < EPSILON)emis_prob = EPSILON;

						//	set the value of ALPHA for observation j
						ALPHA->at<double>(i, j) = emis_prob*temp;

						//	compute the scaling factor
						rf.at<double>(j, 0) += ALPHA->at<double>(i, j);
					}

					//	carry out rescaling of ALPHA
					for (int i = 0; i<N; i++)
						ALPHA->at<double>(i, j) /= rf.at<double>(j, 0);

				}

				// Calculating likelihoods of the observation sequence given the current model
				logProb[countf] = 0.0;
				for (int t = 0; t < T; t++)
				{
					logProb[countf] += -log(rf.at<double>(t, 0));
				}

				// Computing backward variables BETA

				//	Initializing the backward variables for observation T-1 along with rescaling it
				for (int i = 0; i < N; i++)BETA->at<double>(i, T - 1) = 1.0 / rf.at<double>(T - 1, 0);

				// Compouting the backward variables for observations T-2, T-3, ... , to 0
				for (int j = T - 2; j >= 0; j--)
				{
					for (int i = 0; i < N; i++)
					{
						double temp = 0;

						//	iterate over states
						for (int k = 0; k < N; k++)
						{
							//	Store the observation as a column vector
							tmp = new NColVector(SEQ[countf].getObs(j + 1));

							// check for null pointer
							if (tmp == NULL)
							{
								cout << "Null pointer returned during initialization of NCOlVector." << endl;
								return;
							}

							//	initialize emission probability to zero
							emis_prob = 0.0;

							//	compute emission probability by summing over all mixtures
							for (int countk = 0; countk < M; countk++)emis_prob += GAUSS_PROB_[k][countk] * GAUSS[k][countk].getProb(*tmp);

							//	deallocate memory for the temporary column vector
							delete tmp;
							tmp = NULL;

							//	checking if emission probability is below a threshold value
							if (emis_prob < EPSILON)emis_prob = EPSILON;

							//	computing backward variable recursively 
							temp += BETA->at<double>(k, j + 1)*TRANS_.at<double>(i, k)*emis_prob;
						}

						//	setting backward variable
						BETA->at<double>(i, j) = temp;
					}

					//	scaling the backward variable by same factor as the forward variable
					for (int i = 0; i<N; i++)BETA->at<double>(i, j) /= rf.at<double>(j, 0);
				}


				//Computing GAMMA, GAMMA(i,t) specifies the probability of state i at time t given the model and observation sequence

				//	iterating over states
				for (int i = 0; i < N; i++)
				{

					//	iterating over observation sequence
					for (int j = 0; j < T; j++)
					{
						double temp = 0;
						for (int k = 0; k < N; k++)temp += ALPHA->at<double>(k, j)*BETA->at<double>(k, j);
						if (temp < EPSILON)temp = EPSILON;
						GAMMA->at<double>(i, j) = ALPHA->at<double>(i, j)*BETA->at<double>(i, j) / temp;
						if (j == 0)
						{
							//specifying update to the initial probabilities
							num_INIT.at<double>(j, i) += ALPHA->at<double>(i, j)*BETA->at<double>(i, j);
							den_INIT.at<double>(j, i) += temp;

							// checking for values below threshold
							if (den_INIT.at<double>(j, i) < EPSILON)den_INIT.at<double>(j, i) = EPSILON;
						}
					}
				}

				//	Computing CHI, CHI(i,j,t) denotes the probability of being in state i at time t and state j at time t+1 given the model and observation sequence,  0<=t< T-1
				Vector <Mat> CHI;

				//	iterating over observation sequence
				for (int i = 0; i < T - 1; i++)
				{
					//	temporary variable for storing sum
					double tempo = 0;

					//	declare a temporary matrix for storing CHI for observation i
					Mat temp(N, N, CV_64F);

					//	iterating over all states i and j
					for (int j = 0; j < N; j++)
						for (int k = 0; k<N; k++)
							tempo += ALPHA->at<double>(j, i)*TRANS_.at<double>(j, k);

					//	iterating over all states i and j
					for (int j = 0; j < N; j++)
					{
						for (int k = 0; k < N; k++)
						{
							//	Store the observation as a column vector
							tmp = new NColVector(SEQ[countf].getObs(i + 1));

							// check for null pointer
							if (tmp == NULL)
							{
								cout << "Null pointer returned during initialization of NColVector." << endl;
								return;
							}

							//	initialize emission probability to zero
							emis_prob = 0.0;

							//	compute emission probability by summing over all mixtures
							for (int countk = 0; countk < M; countk++)
								emis_prob += GAUSS_PROB_[k][countk] * GAUSS[k][countk].getProb(*tmp);

							//	deallocate memory for the temporary column vector
							delete tmp;
							tmp = NULL;

							//	checking if emission probability is below a threshold value
							if (emis_prob < EPSILON)emis_prob = EPSILON;

							// computing the elements of CHI for obsevation i
							temp.at<double>(j, k) = ALPHA->at<double>(j, i)*TRANS_.at<double>(j, k)*emis_prob*BETA->at<double>(k, i + 1)*rf.at<double>(i + 1, 0) / (tempo);
						}
					}

					//pus the matrix into the vector array
					CHI.push_back(temp);
				}

				//Specifying updates for the transition probability matrix

				//	Summing over all states i,j 
				//	The new transition probability will be the number of  times it was in state i and changed to state j divided by the number of times it was in state i over the entire observation sequence
				for (int i = 0; i < N; i++)
					for (int j = 0; j < N; j++)
					{
					double tmp1, tmp2;
					tmp1 = 0.0;
					tmp2 = 0.0;
					for (int k = 0; k < T - 1; k++)
					{
						tmp1 += CHI[k].at<double>(i, j);
						tmp2 += GAMMA->at<double>(i, k);
					}

					// Updating the numerator and denominator for computing the new transition probabilities
					num_TRANS.at<double>(i, j) += tmp1;
					den_TRANS.at<double>(i, j) += tmp2;

					//	checking for values below threshold
					if (den_TRANS.at<double>(i, j) < EPSILON)den_TRANS.at<double>(i, j) = EPSILON;
					}

				// variable to store the minimum power of 10 in the scaling values, so that it can be ensured no value becomes too low
				int maxLog = 0;
				for (int t = 0; t < T; t++) if (floor(-log(rf.at<double>(t, 0)))>maxLog)maxLog = floor(-log10(rf.at<double>(t, 0)));

				//	specifying updates for Gaussian mixture probabilities
				for (int i = 0; i < N; i++)
				{
					double temp2 = 0.0;
					for (int m = 0; m < M; m++)
					{
						double temp1, temp3;
						temp3 = 0.0;
						for (int t = 1; t < T; t++)
						{
							temp1 = 0.0;

							//	Since actual values of ALPHA and BETA need to be used, we need to undo the scaling, but to ensure no value becomes too small we multiply both numerator anddenominator by a common scale
							for (int j = 0; j < N; j++)temp1 += TRANS_.at<double>(j, i)*ALPHA->at<double>(j, t - 1)*rf.at<double>(t - 1, 0)*pow(10, maxLog);
							temp1 *= GAUSS[i][m].getProb((SEQ[countf].getObs(t)))*BETA->at<double>(i, t)*rf.at<double>(t, 0)*pow(10, maxLog);
							temp3 += temp1;

							//	Updating numerator Gaussian mixture probability
							num_GAUSS_PROB[i][m] += GAUSS_PROB[i][m] * (temp1);
						}
						temp2 += GAUSS_PROB[i][m] * temp3;

						//	Updating denominator Gaussian mixture probability
						den_GAUSS_PROB[i][m] += temp2;
					}
				}

				//	specifying updates for mean and covariance matrices
				for (int i = 0; i < N; i++)
				{
					for (int m = 0; m < M; m++)
					{
						double temp;
						for (int t = 1; t < T; t++)
						{
							temp = 0.0;
							for (int j = 0; j < N; j++)
								temp += TRANS_.at<double>(i, j)*ALPHA->at<double>(j, t - 1)*rf.at<double>(t - 1, 0)*pow(10, maxLog);
							temp *= GAUSS[i][m].getProb((SEQ[countf].getObs(t)))*BETA->at<double>(i, t)*rf.at<double>(t, 0)*pow(10, maxLog);
							num_GAUSS_MEAN[i][m] = num_GAUSS_MEAN[i][m] + ((SEQ[countf].getObs(t)))*temp;
							NColVector v1 = (SEQ[countf].getObs(t));
							v1 = v1 - GAUSS_MEAN_[i][m];
							num_GAUSS_VAR[i][m] = num_GAUSS_VAR[i][m] + ((v1*(v1.transpose())))*temp;
							if (temp < EPSILON)temp = EPSILON;
							den_GAUSS_MEAN[i][m] += temp;
							den_GAUSS_VAR[i][m] += temp;
						}
					}
				}

				//	updating the initial and transition probability matrices and the Gaussian parameters
				//	resetting the numerator and denominators of the updates to 0
				for (int i = 0; i < INIT_.rows; i++)
					for (int j = 0; j < INIT_.cols; j++)
					{
					INIT_.at<double>(i, j) = num_INIT.at<double>(i, j) / den_INIT.at<double>(i, j);
					num_INIT.at<double>(i, j) = 0;
					den_INIT.at<double>(i, j) = 0;
					}
				for (int i = 0; i < TRANS_.rows; i++)
					for (int j = 0; j < TRANS_.cols; j++)
					{
					TRANS_.at<double>(i, j) = num_TRANS.at<double>(i, j) / den_TRANS.at<double>(i, j);
					num_TRANS.at<double>(i, j) = 0;
					den_TRANS.at<double>(i, j) = 0;
					}
				for (int i = 0; i < N; i++)
					for (int j = 0; j < M; j++)
					{
					GAUSS_PROB_[i][j] = num_GAUSS_PROB[i][j] / den_GAUSS_PROB[i][j];
					num_GAUSS_PROB[i][j] = 0;
					den_GAUSS_PROB[i][j] = 0;
					GAUSS_MEAN_[i][j] = (1.0 / den_GAUSS_MEAN[i][j])*num_GAUSS_MEAN[i][j];
					num_GAUSS_MEAN[i][j] = NColVector(15, 0.0);
					den_GAUSS_MEAN[i][j] = 0;
					GAUSS_VAR_[i][j] = (1.0 / den_GAUSS_VAR[i][j])*num_GAUSS_VAR[i][j];
					num_GAUSS_VAR[i][j] = Mat(15, 15, CV_64F, Scalar(0));
					den_GAUSS_PROB[i][j] = 0;
					}

				//	rescale each row of the transition matrix so that probabilities add up to 1

				//	variable for storing sum of each row
				double normsum;
				for (int i = 0; i<TRANS_.rows; i++)
				{
					normsum = 0;
					for (int j = 0; j<TRANS_.cols; j++)
						normsum += TRANS_.at<double>(i, j);
					for (int j = 0; j<TRANS_.cols; j++)
						TRANS_.at<double>(i, j) /= normsum;	//normalizing trans
				}
				//	computing the new likelihood of the observation sequence given the model

				//	resetting the scale factors to 0
				for (int i = 0; i<T; i++)
					rf.at<double>(i, 0) = 0;

				//computing forward variables once again

				//	initial iteration over all states
				for (int i = 0; i < N; i++)
				{
					//	Store the observation as a column vector
					tmp = new NColVector(SEQ[countf].getObs(0));

					//	check for null pointer
					if (tmp == NULL)
					{
						cout << "Null pointer returned during initialization of NCOlVector." << endl;
						return -1;
					}

					//	initializing emission probability to 0
					emis_prob = 0.0;

					//	computing the emission probability by summing over all mixtures of the Gaussian
					for (int countk = 0; countk < M; countk++)emis_prob += GAUSS_PROB_[i][countk] * GAUSS[i][countk].getProb(*tmp);

					//	deallocate memory for the temporary column vector
					delete tmp;
					tmp = NULL;

					//	compute the forward variable for initial observation
					ALPHA->at<double>(i, 0) = INIT_.at<double>(0, i)*emis_prob;

					//	compute scaling factor
					rf.at<double>(0, 0) += ALPHA->at<double>(i, 0);
				}

				//	rescale the forward variables
				for (int i = 0; i<N; i++)
					ALPHA->at<double>(i, 0) /= rf.at<double>(0, 0);

				//	recursive computation of forward variables for observations 1,2,..,T-1
				for (int j = 1; j < T; j++)
				{
					for (int i = 0; i < N; i++)
					{
						double temp = 0;
						for (int k = 0; k < N; k++)
						{
							temp += ALPHA->at<double>(k, j - 1)*TRANS_.at<double>(k, i);
						}

						//	Store the observation as a column vector
						tmp = new NColVector(SEQ[countf].getObs(j));

						//	check for null pointer
						if (tmp == NULL)
						{
							cout << "Null pointer returned during initialization of NCOlVector." << endl;
							return -1;
						}

						//	initializing emission probability to 0
						emis_prob = 0.0;

						//	computing the emission probability by summing over all mixtures of the Gaussian
						for (int countk = 0; countk < M; countk++)emis_prob += GAUSS_PROB_[i][countk] * (GAUSS[i][countk].getProb(*tmp));

						//	deallocate memory for the temporary column vector
						delete tmp;
						tmp = NULL;

						//	compute the forward variable for observation j
						ALPHA->at<double>(i, j) = emis_prob;

						//	compute the scalingg factor
						rf.at<double>(j, 0) = ALPHA->at<double>(i, j);
					}

					//	rescale the forward variables
					for (int i = 0; i<N; i++)
						ALPHA->at<double>(i, j) /= rf.at<double>(j, 0);
				}

				//	compute new negative logarithm of the likelihood of the observation sequence given the model
				newLogProb[countf] = 0.0;
				for (int t = 0; t < N; t++)
				{
					newLogProb[countf] += -log(rf.at<double>(t, 0));
				}
				diffLogProb[countf] = newLogProb[countf] - logProb[countf];
			}
			probLogDiff = NColVector(faces, diffLogProb);
			for (int countf = 0; countf < faces; countf++)
				logProb[countf] = newLogProb[countf];


			//	storing the trained parameters into the main class variables
			*TRANS = TRANS_.clone();
			*INIT = INIT_.clone();
			for (int i = 0; i < states; i++)
				for (int j = 0; j < mixtures; j++)
				{
				GAUSS_PROB[i][j] = GAUSS_PROB_[i][j];
				GAUSS_MEAN[i][j] = GAUSS_MEAN_[i][j];
				GAUSS_VAR[i][j] = GAUSS_VAR_[i][j];
				GAUSS[i][j].setMean(GAUSS_MEAN[i][j]);
				GAUSS[i][j].setVar(GAUSS_VAR[i][j]);
				}

			//incrementing the number of itrations completed
			count++;

		} while (probLogDiff.getNorm() / (faces) > probLimit && count < maxCount);

		//	on successful training return 0
		return 0;
	}

	/*
	*	Function to display the HMM parameters on console
	*/
	void print()
	{
		cout << "Showing init..." << endl;
		for (int i = 0; i<INIT->rows; i++)
		{
			for (int j = 0; j<INIT->cols; j++)
				cout << INIT->at<double>(i, j) << " ";
			cout << endl;
		}
		cout << endl;
		cout << "Showing trans..." << endl;
		for (int i = 0; i<TRANS->rows; i++)
		{
			for (int j = 0; j<TRANS->cols; j++)
				cout << TRANS->at<double>(i, j) << " ";
			cout << endl;
		}
		cout << endl;
		cout << "Showing mean..." << endl;
		for (int i = 0; i<states; i++)
		{
			for (int j = 0; j<mixtures; j++)
			{
				for (int k = 0; k<15; k++)
					cout << GAUSS_MEAN[i][j].getElement(k) << " ";
				cout << "<>";
			}
			cout << endl;
		}

		cout << "Showing covariance mattrices ..." << endl;
		for (int i = 0; i<states; i++)
			for (int j = 0; j<mixtures; j++)
				cout << GAUSS_VAR[i][j] << endl;
	}

};

/*
*	The following is a class definition for Person.
*	It implements a model of a test subject with a unique id and number of faces asscociated with the subject.
*/
class Person
{
	static unsigned long int num;
	unsigned long int id;
	unsigned int num_of_faces;
public:
	Person();
	Person(unsigned int nof);
	unsigned long int getId(){ return id; }
	bool train(int &max_iter);
	double detect();
};

unsigned long int Person::num = 0;

/*
*	Default constructor for Person
*/
Person::Person()
{
	// increment the total number of persons in database
	//	each person has a unique id based on the order in which a Person object is created
	id = ++num;

	//	default number of faces is 10
	num_of_faces = 10;
}

Person::Person(unsigned int nof)
{
	id = ++num;
	num_of_faces = nof;
}

/*
*	FUnction to train a separate HMM for each Person, it takes as parameter the number of maximum iterations of the Baum-Welch algorithm to be allowed while training the model
*/
bool Person::train(int &max_iter)
{


	Obs *observation = new Obs[num_of_faces];
	if (observation == NULL)
	{
		cout << "Null pointer returned during initialization of observation." << endl;
		return false;
	}
	for (int iter = 0; iter<num_of_faces; iter++)
	{
		//declare a filestream which reads images in folder with name same as id and path as specified
		stringstream filename;
		filename << (id) << "/" << (iter) << ".jpg";

		//	read image
		Mat image;
		image = cv::imread(filename.str(), CV_LOAD_IMAGE_GRAYSCALE);

		//	check if image was corrrectly read
		if (!image.data)
		{
			cout << "Could not read image. Error ..." << endl;
			return false;
		}

		//check if image size matches with definition
		if (image.rows != IMG_ROW || image.cols != IMG_COL)
			cv::resize(image, image, cv::Size2d(IMG_ROW, IMG_COL));

		//extract the DCT coefficients of the image

		//an array to store the partial DCT coefficients 
		double tmp[SW_SIZE][SW_SIZE];

		//for loop to iterate over the DCT matrices, each of which is a part of a matrix itself of DCT_NUM1*DCT_NUM2 elements
		for (int i = 0; i < DCT_NUM1; i++)
		{
			//for loop to iterate over the DCT matrices, each of which is a part of a matrix itself of DCT_NUM1*DCT_NUM2 elements
			for (int j = 0; j < DCT_NUM2; j++)
			{

				//	the number in which order this DCT matrix will appear in the matrix of DCT matrices 
				int num = DCT_NUM1 * i + j;

				//	the starting point(row) of the sliding window in the image
				int start_row = APP_SIZE * i;

				//	the starting point(column) of the sliding window in the image
				int start_col = APP_SIZE * j;

				//	the opposite corner of sliding window(row) in image
				int end_row = start_row + SW_SIZE;

				//	the opposite corner of sliding window (column) in image
				int end_col = start_col + SW_SIZE;

				// coefficient to be mutiplied with cosine terms
				double alpha;

				//	computing DCT
				for (int u = 0; u < SW_SIZE; u++)
				{
					for (int v = 0; v < SW_SIZE; v++)
					{
						tmp[u][v] = 0;
						alpha = (v != 0) ? 1 : INVSQRT2;
						for (int x = start_col, y = start_row + u; x < end_col; x++)
							tmp[u][v] += (alpha*cos(PI *(2 * x + 1)*v / (2 * SW_SIZE))*((int)image.at<uchar>(y, x)));
					}
				}
				for (int u = 0; u<SW_SIZE; u++)
				{
					for (int v = 0; v<SW_SIZE; v++)
					{
						DCT[num][u][v] = 0.0;
						alpha = (v != 0) ? 1 : INVSQRT2;
						for (int y = 0, x = u; y < SW_SIZE; y++)
							DCT[num][u][v] += (alpha*cos(PI *(2 * y + 1)*u / (2 * SW_SIZE))*(tmp[y][x]));
						DCT[num][u][v] = DCT[num][u][v] / (SW_SIZE*SW_SIZE);
					}
				}
			}
		}
		//	store observation sequence
		observation[iter] = Obs(DCT, DCT_NUM1*DCT_NUM2);
	}

	//	create a HMM model
	HMM model(observation, num_of_faces, DCT_NUM1*DCT_NUM2, 6, 1);

	//	train the model
	model.train(10, max_iter);
	//store hmm parameters, file has header denoting training maximized likelihood
	stringstream outfilename;
	outfilename << (id) << ".hmm";
	model.write(outfilename.str());

}

// definition of detect() function declared in class Person
double Person::detect()
{
	stringstream infilename("");
	infilename << (id) << ".hmm";
	HMM model(5);
	model.read(infilename.str(), "0.jpg");
	return model.ViterbiLikelihood();
}

#endif