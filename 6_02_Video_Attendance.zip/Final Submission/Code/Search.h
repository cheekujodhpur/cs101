/*
A Video Attendance Module
Copyright (C) Slot 6:Group 2:Reebhu,Keshav,Ayush,Kshitij

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
*/

#pragma once

/*External Libraries*/
#include<iostream>
#include<opencv2\core\core.hpp>
#include<fstream>
#include<stdlib.h>

/*Header Files*/
#include"Main.h"
/*Global Var p*/
extern int p;

namespace VAM {

	/*namespaces*/
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

		/*Class to Search a User*/
		public ref class Search : public System::Windows::Forms::Form
		{
		public:
			/*Constructor*/
			Search(void)
			{
				/*Init Function*/
				InitializeComponent();
			}

		protected:
			/*Destructor*/
			~Search()
			{
				if (components)
				{
					delete components;
				}
			}
		private: System::Windows::Forms::Label^  label1;
		private: System::Windows::Forms::Label^  label2;
		private: System::Windows::Forms::RadioButton^  radioButton1;
		private: System::Windows::Forms::RadioButton^  radioButton2;
		private: System::Windows::Forms::RadioButton^  radioButton3;
		private: System::Windows::Forms::RadioButton^  radioButton4;
		private: System::Windows::Forms::TextBox^  textBox1;
		private: System::Windows::Forms::Label^  label3;
		private: System::Windows::Forms::Label^  label4;
		private: System::Windows::Forms::Label^  label5;
		private: System::Windows::Forms::Label^  label6;
		private: System::Windows::Forms::Label^  label7;
		private: System::Windows::Forms::Button^  button3;
		private: System::Windows::Forms::Button^  button4;
		private: System::Windows::Forms::Button^  button1;

		private:
			/*Component Form*/
			System::ComponentModel::Container ^components;

	#pragma region Windows Form Designer generated code
			/*Initializer function*/
			void InitializeComponent(void)
			{
				this->label1 = (gcnew System::Windows::Forms::Label());
				this->label2 = (gcnew System::Windows::Forms::Label());
				this->radioButton1 = (gcnew System::Windows::Forms::RadioButton());
				this->radioButton2 = (gcnew System::Windows::Forms::RadioButton());
				this->radioButton3 = (gcnew System::Windows::Forms::RadioButton());
				this->radioButton4 = (gcnew System::Windows::Forms::RadioButton());
				this->textBox1 = (gcnew System::Windows::Forms::TextBox());
				this->label3 = (gcnew System::Windows::Forms::Label());
				this->label4 = (gcnew System::Windows::Forms::Label());
				this->label5 = (gcnew System::Windows::Forms::Label());
				this->label6 = (gcnew System::Windows::Forms::Label());
				this->label7 = (gcnew System::Windows::Forms::Label());
				this->button3 = (gcnew System::Windows::Forms::Button());
				this->button4 = (gcnew System::Windows::Forms::Button());
				this->button1 = (gcnew System::Windows::Forms::Button());
				this->SuspendLayout();
				// 
				// label1
				// 
				this->label1->AutoSize = true;
				this->label1->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
					static_cast<System::Byte>(0)));
				this->label1->Location = System::Drawing::Point(378, 173);
				this->label1->Name = L"label1";
				this->label1->Size = System::Drawing::Size(134, 28);
				this->label1->TabIndex = 14;
				this->label1->Text = L"For Students";
				// 
				// label2
				// 
				this->label2->AutoSize = true;
				this->label2->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
					static_cast<System::Byte>(0)));
				this->label2->Location = System::Drawing::Point(56, 173);
				this->label2->Name = L"label2";
				this->label2->Size = System::Drawing::Size(114, 28);
				this->label2->TabIndex = 15;
				this->label2->Text = L"For Admin:";
				// 
				// radioButton1
				// 
				this->radioButton1->AutoSize = true;
				this->radioButton1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
					static_cast<System::Byte>(0)));
				this->radioButton1->Location = System::Drawing::Point(49, 232);
				this->radioButton1->Name = L"radioButton1";
				this->radioButton1->Size = System::Drawing::Size(108, 28);
				this->radioButton1->TabIndex = 16;
				this->radioButton1->TabStop = true;
				this->radioButton1->Text = L"By Name";
				this->radioButton1->UseVisualStyleBackColor = true;
				this->radioButton1->Click += gcnew System::EventHandler(this, &Search::radioButton1_Click);
				// 
				// radioButton2
				// 
				this->radioButton2->AutoSize = true;
				this->radioButton2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
					static_cast<System::Byte>(0)));
				this->radioButton2->Location = System::Drawing::Point(376, 232);
				this->radioButton2->Name = L"radioButton2";
				this->radioButton2->Size = System::Drawing::Size(108, 28);
				this->radioButton2->TabIndex = 17;
				this->radioButton2->TabStop = true;
				this->radioButton2->Text = L"By Name";
				this->radioButton2->UseVisualStyleBackColor = true;
				this->radioButton2->Click += gcnew System::EventHandler(this, &Search::radioButton2_Click);
				// 
				// radioButton3
				// 
				this->radioButton3->AutoSize = true;
				this->radioButton3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
					static_cast<System::Byte>(0)));
				this->radioButton3->Location = System::Drawing::Point(376, 294);
				this->radioButton3->Name = L"radioButton3";
				this->radioButton3->Size = System::Drawing::Size(163, 28);
				this->radioButton3->TabIndex = 18;
				this->radioButton3->TabStop = true;
				this->radioButton3->Text = L"By Roll Number";
				this->radioButton3->UseVisualStyleBackColor = true;
				this->radioButton3->Click += gcnew System::EventHandler(this, &Search::radioButton3_Click);
				// 
				// radioButton4
				// 
				this->radioButton4->AutoSize = true;
				this->radioButton4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
					static_cast<System::Byte>(0)));
				this->radioButton4->Location = System::Drawing::Point(376, 353);
				this->radioButton4->Name = L"radioButton4";
				this->radioButton4->Size = System::Drawing::Size(169, 28);
				this->radioButton4->TabIndex = 19;
				this->radioButton4->TabStop = true;
				this->radioButton4->Text = L"By Unique Code";
				this->radioButton4->UseVisualStyleBackColor = true;
				this->radioButton4->Click += gcnew System::EventHandler(this, &Search::radioButton4_Click);
				// 
				// textBox1
				// 
				this->textBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
					static_cast<System::Byte>(0)));
				this->textBox1->Location = System::Drawing::Point(79, 63);
				this->textBox1->Name = L"textBox1";
				this->textBox1->Size = System::Drawing::Size(316, 30);
				this->textBox1->TabIndex = 20;
				// 
				// label3
				// 
				this->label3->AutoSize = true;
				this->label3->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
					static_cast<System::Byte>(0)));
				this->label3->Location = System::Drawing::Point(219, 173);
				this->label3->Name = L"label3";
				this->label3->Size = System::Drawing::Size(114, 28);
				this->label3->TabIndex = 23;
				this->label3->Text = L"For Admin:";
				this->label3->Visible = false;
				// 
				// label4
				// 
				this->label4->AutoSize = true;
				this->label4->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
					static_cast<System::Byte>(0)));
				this->label4->Location = System::Drawing::Point(74, 232);
				this->label4->Name = L"label4";
				this->label4->Size = System::Drawing::Size(114, 28);
				this->label4->TabIndex = 24;
				this->label4->Text = L"For Admin:";
				this->label4->Visible = false;
				this->label4->Click += gcnew System::EventHandler(this, &Search::label4_Click);
				// 
				// label5
				// 
				this->label5->AutoSize = true;
				this->label5->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
					static_cast<System::Byte>(0)));
				this->label5->Location = System::Drawing::Point(241, 232);
				this->label5->Name = L"label5";
				this->label5->Size = System::Drawing::Size(114, 28);
				this->label5->TabIndex = 25;
				this->label5->Text = L"For Admin:";
				this->label5->Visible = false;
				// 
				// label6
				// 
				this->label6->AutoSize = true;
				this->label6->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
					static_cast<System::Byte>(0)));
				this->label6->Location = System::Drawing::Point(74, 323);
				this->label6->Name = L"label6";
				this->label6->Size = System::Drawing::Size(114, 28);
				this->label6->TabIndex = 26;
				this->label6->Text = L"For Admin:";
				this->label6->Visible = false;
				// 
				// label7
				// 
				this->label7->AutoSize = true;
				this->label7->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
					static_cast<System::Byte>(0)));
				this->label7->Location = System::Drawing::Point(241, 323);
				this->label7->Name = L"label7";
				this->label7->Size = System::Drawing::Size(114, 28);
				this->label7->TabIndex = 27;
				this->label7->Text = L"For Admin:";
				this->label7->Visible = false;
				// 
				// button3
				// 
				this->button3->Location = System::Drawing::Point(41, 431);
				this->button3->Name = L"button3";
				this->button3->Size = System::Drawing::Size(116, 36);
				this->button3->TabIndex = 30;
				this->button3->Text = L"Back";
				this->button3->UseVisualStyleBackColor = true;
				this->button3->Click += gcnew System::EventHandler(this, &Search::button3_Click);
				// 
				// button4
				// 
				this->button4->Location = System::Drawing::Point(460, 431);
				this->button4->Name = L"button4";
				this->button4->Size = System::Drawing::Size(116, 36);
				this->button4->TabIndex = 32;
				this->button4->Text = L"Clear";
				this->button4->UseVisualStyleBackColor = true;
				this->button4->Click += gcnew System::EventHandler(this, &Search::button4_Click);
				// 
				// button1
				// 
				this->button1->Location = System::Drawing::Point(448, 57);
				this->button1->Name = L"button1";
				this->button1->Size = System::Drawing::Size(116, 36);
				this->button1->TabIndex = 33;
				this->button1->Text = L"Search ";
				this->button1->UseVisualStyleBackColor = true;
				this->button1->Click += gcnew System::EventHandler(this, &Search::button1_Click_1);
				// 
				// Search
				// 
				this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
				this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
				this->ClientSize = System::Drawing::Size(616, 497);
				this->Controls->Add(this->button1);
				this->Controls->Add(this->button4);
				this->Controls->Add(this->button3);
				this->Controls->Add(this->label7);
				this->Controls->Add(this->label6);
				this->Controls->Add(this->label5);
				this->Controls->Add(this->label4);
				this->Controls->Add(this->label3);
				this->Controls->Add(this->textBox1);
				this->Controls->Add(this->radioButton4);
				this->Controls->Add(this->radioButton3);
				this->Controls->Add(this->radioButton2);
				this->Controls->Add(this->radioButton1);
				this->Controls->Add(this->label2);
				this->Controls->Add(this->label1);
				this->Name = L"Search";
				this->Text = L"Search";
				this->ResumeLayout(false);
				this->PerformLayout();

			}
	#pragma endregion
	
		private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {
			textBox1->Text = "";
			this->Hide();
		}
		private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) {
			textBox1->Text = "";
		}
		private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
			label3->Visible = false;
			label4->Visible = false;
			label5->Visible = false;
			label6->Visible = false;
			label7->Visible = false;
			textBox1->Text = "";
			button3->Visible = true;
			label1->Visible = true;
			label2->Visible = true;
			radioButton1->Visible = true;
			radioButton2->Visible = true;
			radioButton3->Visible = true;
			radioButton4->Visible = true;
		}
		 
		private: System::Void radioButton2_Click(System::Object^  sender, System::EventArgs^  e) {
			p = 2;
		}
		private: System::Void radioButton3_Click(System::Object^  sender, System::EventArgs^  e) {
			p = 3;
		}
		private: System::Void radioButton4_Click(System::Object^  sender, System::EventArgs^  e) {
			p = 4;
		}
		private: System::Void label4_Click(System::Object^  sender, System::EventArgs^  e) {
		}
		private: System::Void radioButton1_Click(System::Object^  sender, System::EventArgs^  e) {
			p = 1;
		}
		private: System::Void button1_Click_1(System::Object^  sender, System::EventArgs^  e) {
			button4->Visible = false;
			string search;
			MarshalString(textBox1->Text, search);
			ifstream myfile;
			myfile.open("stu_index.txt");
			int index;
			myfile >> index;
			__Student_Current_Index = index;
			myfile.close();
			if (radioButton1->Checked)
			{
				cv::FileStorage fs("admin.yml", cv::FileStorage::READ);
				Admin_Info searchadmin;
				fs[search] >> searchadmin;
				if (searchadmin.admin_access == 100)
				{
					label3->Visible = true;
					label3->Text = "NotFound";
					label1->Visible = false;
					label2->Visible = false;
					radioButton1->Visible = false;
					radioButton2->Visible = false;
					radioButton3->Visible = false;
					radioButton4->Visible = false;
				}
				else
				{
					label1->Visible = false;
					label2->Visible = false;
					radioButton1->Visible = false;
					radioButton2->Visible = false;
					radioButton3->Visible = false;
					radioButton4->Visible = false;
					label3->Visible = true;
					label3->Text = "Found!";
					System::String^ access = gcnew System::String(to_string(searchadmin.admin_access).c_str());
					label4->Visible = true;
					label4->Text = "Name:";
					label5->Visible = true;
					label5->Text = textBox1->Text;
					label6->Visible = true;
					label6->Text = "Admin Access : ";
					label7->Visible = true;
					label7->Text = "Level" + access + "Access";
				}
			}
			else if (radioButton2->Checked)
			{
				bool flag;
				Student_Info searchstudent;
				cv::FileStorage fs("students.yml", cv::FileStorage::READ);
				for (int i = 0; i < __Student_Current_Index; i++)
				{
					string temp = "s_" + to_string(i);
					fs[temp] >> searchstudent;
					if (searchstudent.name == search)
					{
						flag = 1;
						break;
					}
				}
				if (flag)
				{

					label1->Visible = false;
					label2->Visible = false;
					radioButton1->Visible = false;
					radioButton2->Visible = false;
					radioButton3->Visible = false;
					radioButton4->Visible = false;
					label3->Visible = true;
					label3->Text = "Found!";
					System::String^ roll_number = gcnew System::String(searchstudent.roll_no.c_str());
					label4->Visible = true;
					label4->Text = "Name:";
					label5->Visible = true;
					label5->Text = textBox1->Text;
					label6->Visible = true;
					label6->Text = "Roll Number: ";
					label7->Visible = true;
					label7->Text = roll_number;
				}
				else
				{
					label1->Visible = false;
					label2->Visible = false;
					radioButton1->Visible = false;
					radioButton2->Visible = false;
					radioButton3->Visible = false;
					radioButton4->Visible = false;
					label3->Visible = true;
					label3->Text = "Not Found!";
				}
			}
			else if (radioButton3->Checked)
			{
				bool flag;
				Student_Info searchstudent;
				cv::FileStorage fs("students.yml", cv::FileStorage::READ);
				for (int i = 0; i < __Student_Current_Index; i++)
				{
					string temp = "s_" + to_string(i);
					fs[temp] >> searchstudent;
					if (searchstudent.roll_no == search)
					{
						flag = 1;
						break;
					}
				}
				if (flag)
				{

					label1->Visible = false;
					label2->Visible = false;
					radioButton1->Visible = false;
					radioButton2->Visible = false;
					radioButton3->Visible = false;
					radioButton4->Visible = false;
					label3->Visible = true;
					label3->Text = "Found!";
					System::String^ name = gcnew System::String(searchstudent.name.c_str());
					label4->Visible = true;
					label4->Text = "Name:";
					label5->Visible = true;
					label5->Text = name;
					label6->Visible = true;
					label6->Text = "Roll Number: ";
					label7->Visible = true;
					label7->Text = textBox1->Text;
				}
				else
				{
					label1->Visible = false;
					label2->Visible = false;
					radioButton1->Visible = false;
					radioButton2->Visible = false;
					radioButton3->Visible = false;
					radioButton4->Visible = false;
					label3->Visible = true;
					label3->Text = "Not Found!";
				}
			}
			else if (radioButton4->Checked)
			{
				Student_Info searchstudent;
				cv::FileStorage fs("students.yml", cv::FileStorage::READ);
				string temp = "s_" + search;
				fs[temp] >> searchstudent;
				if (searchstudent.roll_no == "void")
				{
					label1->Visible = false;
					label2->Visible = false;
					radioButton1->Visible = false;
					radioButton2->Visible = false;
					radioButton3->Visible = false;
					radioButton4->Visible = false;
					label3->Visible = true;
					label3->Text = "Not Found!";
				}
				else
				{
					label1->Visible = false;
					label2->Visible = false;
					radioButton1->Visible = false;
					radioButton2->Visible = false;
					radioButton3->Visible = false;
					radioButton4->Visible = false;
					label3->Visible = true;
					label3->Text = "Found!";
					System::String^ name = gcnew System::String(searchstudent.name.c_str());
					System::String^ rollno = gcnew System::String(searchstudent.roll_no.c_str());
					label4->Visible = true;
					label4->Text = "Name:";
					label5->Visible = true;
					label5->Text = name;
					label6->Visible = true;
					label6->Text = "Roll Number: ";
					label7->Visible = true;
					label7->Text = rollno;
				}
			}
		}
	};
}