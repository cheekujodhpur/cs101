/*
A Video Attendance Module
Copyright (C) Slot 6:Group 2:Reebhu,Keshav,Ayush,Kshitij

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
*/

/*The VideoAttendance Class
* Has the Windows Form for the main page of our GUI
*/
#include "VideoAttendance.h"

/*Namespaces to utilize Windows SDK*/
using namespace System;
using namespace System::Windows::Forms;

/* Global Variables
*  For initialization, see Main.h
*  These need to be declared for clean external linkage
*/

/*Maintains current index of student; init to 0; should be read from a file, stu_index.txt*/
int __Student_Current_Index = 0;

/*Maintains number of photos to be taken on init of data collections, can be changed from Settings*/
int __Num_Photos = 10;

/*Maintains current index of admin; init to 0; should be read from a file, admin.yml*/
int __Admin_Current_Index = 0;

/*Signifies the access level of a user;0 is student;1 is admin;2 is superuser*/
int __Access_Level = 0;

/*Maintains the name of the current admin*/
string __Admin_Current_User = "";

/*Maintains the file number to which the photo is being written*/
int __File_Number = 0;

/*Maintains the Threshold over which we give a confirmed match*/
double __Threshold = 1000;

/*Maintains the number of __Num_Eigenfaces to train in our model*/
int __Num_Eigenfaces = 10;

int Main()
{
	/*Enable Visual Styles*/
	Application::EnableVisualStyles();

	/*Initalize a form*/
	VAM::VideoAttendance Program;

	/*Run the program*/
	Application::Run(%Program);
	return 0;
}
