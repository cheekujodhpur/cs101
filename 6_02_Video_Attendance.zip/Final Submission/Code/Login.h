/*
A Video Attendance Module
Copyright (C) Slot 6:Group 2:Reebhu,Keshav,Ayush,Kshitij

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
*/

#pragma once

/*External Library Files*/
#include <opencv2/core/core.hpp>
#include <iostream>
#include <string>

/*Main Files*/
#include "Admin.h"
#include "Main.h"

/*namespaces*/
using namespace std;
using namespace System;

namespace VAM {
	
	/*Windows SDK Namespaces*/
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	

		public ref class Login : public System::Windows::Forms::Form
		{
		public:
			/*Constructor*/
			Login(void)
			{
				/*Init function*/
				InitializeComponent();
			}

		protected:
			/*Destructor*/
			~Login()
			{
				if (components)
				{
					delete components;
				}
			}
		private: System::Windows::Forms::Button^  button2;
		private: System::Windows::Forms::TextBox^  textBox1;
		private: System::Windows::Forms::TextBox^  textBox2;
		private: System::Windows::Forms::Label^  label1;
		private: System::Windows::Forms::Label^  label2;
		private: System::Windows::Forms::Button^  button1;
		private: System::ComponentModel::Container ^components;

	#pragma region Windows Form Designer generated code
			void InitializeComponent(void)
			{
				this->button2 = (gcnew System::Windows::Forms::Button());
				this->textBox1 = (gcnew System::Windows::Forms::TextBox());
				this->textBox2 = (gcnew System::Windows::Forms::TextBox());
				this->label1 = (gcnew System::Windows::Forms::Label());
				this->label2 = (gcnew System::Windows::Forms::Label());
				this->button1 = (gcnew System::Windows::Forms::Button());
				this->SuspendLayout();
				// 
				// button2
				// 
				this->button2->Location = System::Drawing::Point(95, 189);
				this->button2->Name = L"button2";
				this->button2->Size = System::Drawing::Size(96, 37);
				this->button2->TabIndex = 1;
				this->button2->Text = L"Ok";
				this->button2->UseVisualStyleBackColor = true;
				this->button2->Click += gcnew System::EventHandler(this, &Login::button2_Click);
				// 
				// textBox1
				// 
				this->textBox1->Location = System::Drawing::Point(217, 55);
				this->textBox1->Name = L"textBox1";
				this->textBox1->Size = System::Drawing::Size(235, 22);
				this->textBox1->TabIndex = 2;
				// 
				// textBox2
				// 
				this->textBox2->Location = System::Drawing::Point(217, 110);
				this->textBox2->Name = L"textBox2";
				this->textBox2->Size = System::Drawing::Size(235, 22);
				this->textBox2->TabIndex = 3;
				// 
				// label1
				// 
				this->label1->AutoSize = true;
				this->label1->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
					static_cast<System::Byte>(0)));
				this->label1->Location = System::Drawing::Point(54, 49);
				this->label1->Name = L"label1";
				this->label1->Size = System::Drawing::Size(110, 28);
				this->label1->TabIndex = 4;
				this->label1->Text = L"Username:";
				// 
				// label2
				// 
				this->label2->AutoSize = true;
				this->label2->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
					static_cast<System::Byte>(0)));
				this->label2->Location = System::Drawing::Point(54, 104);
				this->label2->Name = L"label2";
				this->label2->Size = System::Drawing::Size(105, 28);
				this->label2->TabIndex = 5;
				this->label2->Text = L"Password:";
				// 
				// button1
				// 
				this->button1->Location = System::Drawing::Point(332, 189);
				this->button1->Name = L"button1";
				this->button1->Size = System::Drawing::Size(96, 37);
				this->button1->TabIndex = 6;
				this->button1->Text = L"Cancel";
				this->button1->UseVisualStyleBackColor = true;
				this->button1->Click += gcnew System::EventHandler(this, &Login::button1_Click);
				// 
				// Login
				// 
				this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
				this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
				this->ClientSize = System::Drawing::Size(519, 253);
				this->Controls->Add(this->button1);
				this->Controls->Add(this->label2);
				this->Controls->Add(this->label1);
				this->Controls->Add(this->textBox2);
				this->Controls->Add(this->textBox1);
				this->Controls->Add(this->button2);
				this->Name = L"Login";
				this->Text = L"Login";
				this->Load += gcnew System::EventHandler(this, &Login::Login_Load);
				this->ResumeLayout(false);
				this->PerformLayout();

			}
		
		private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			/*Clear Button*/
			textBox1->Text = "";
			textBox2->Text = "";
			this->Hide();
		}
		private: System::Void Login_Load(System::Object^  sender, System::EventArgs^  e) {
			/*Password must be hidden*/
			textBox2->UseSystemPasswordChar = true;
		}
		private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
		
			/*Get Info and verify if allowed access*/
			bool flag = 0;

			/*The admin class*/
			Admin_Info admin_info;
			string text1, text2;

			/*String conversion*/
			MarshalString(textBox1->Text, text1);
			MarshalString(textBox2->Text, text2);

			/*Admin File Storage*/
			cv::FileStorage file_pointer("admin.yml", cv::FileStorage::READ);

			//read value into admin info object
			file_pointer[text1] >> admin_info;

			if ((admin_info.admin_access == 100) || (text2 != admin_info.password))
			{
				flag = 1;	//check if wrong admin found
			}
			if (flag)
			{
				/*Error messages et.al. in case of wrong username password combination*/
				if (MessageBox::Show("Invalid Username or Password", "Error", MessageBoxButtons::RetryCancel, MessageBoxIcon::Exclamation) == System::Windows::Forms::DialogResult::Retry)
				{
					textBox1->Text = "";
					textBox2->Text = "";
				}
				else
				{
					textBox1->Text = "";
					textBox2->Text = "";
					this->Hide();
				}
			}
			else
			{
				/*In case of successful login*/
				__Access_Level = admin_info.admin_access;
				textBox1->Text = "";
				textBox2->Text = "";
				__Admin_Current_User = text1;

				/*Make a new admin module and show it*/
				Admin ^admin_module = gcnew Admin();
				admin_module->Show();

				/*Hide the login module*/
				this->Hide();
			}
			/*Release File Storage*/
			file_pointer.release();
		}
	};
}

#pragma endregion