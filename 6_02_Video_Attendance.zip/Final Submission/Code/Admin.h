/*
A Video Attendance Module
Copyright (C) Slot 6:Group 2:Reebhu,Keshav,Ayush,Kshitij

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
*/

#pragma once

/*External Libraries*/
#include <opencv2/core/core.hpp>
#include <iostream>
#include <string>

/*Header Files*/
#include "Detect.h"
#include "Main.h"
#include "MyForm.h"
#include "New Student.h"
#include "Marshal.h"
#include "Search.h"
#include "Settings.h"
#include "Retake.h"

/*The access level global var*/
extern int __Access_Level;

namespace VAM {
	/*namespaces*/
	using namespace cv;
	using namespace std;
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

		public ref class Admin : public System::Windows::Forms::Form
		{
		public:
			/*Constructor*/
			Admin(void)
			{
				//init functions
				InitializeComponent();
			}

		protected:
			~Admin()
			{
				if (components)
				{
					delete components;
				}
			}
		/*Form Items*/
		private: System::Windows::Forms::MenuStrip^  menuStrip1;
		private: System::Windows::Forms::ToolStripMenuItem^  addToolStripMenuItem;
		private: System::Windows::Forms::ToolStripMenuItem^  studentToolStripMenuItem;
		private: System::Windows::Forms::ToolStripMenuItem^  adminToolStripMenuItem;
		private: System::Windows::Forms::ToolStripMenuItem^  generalSettingToolStripMenuItem;
		private: System::Windows::Forms::ToolStripMenuItem^  generalToolStripMenuItem;
		private: System::Windows::Forms::ToolStripMenuItem^  advancedToolStripMenuItem;
		private: System::Windows::Forms::ToolStripMenuItem^  helpToolStripMenuItem;
		private: System::Windows::Forms::ToolStripMenuItem^  aboutToolStripMenuItem;
		private: System::Windows::Forms::ToolStripMenuItem^  exitToolStripMenuItem;
		private: System::Windows::Forms::ToolStripMenuItem^  searchToolStripMenuItem;
		private: System::Windows::Forms::Button^  button2;
		private: System::Windows::Forms::Label^  label1;
		private: System::Windows::Forms::Label^  label2;
		private: System::Windows::Forms::Label^  label3;
		private: System::Windows::Forms::Timer^  timer1;
		private: System::Windows::Forms::ToolStripMenuItem^  trainToolStripMenuItem;
		private: System::Windows::Forms::ToolStripMenuItem^  retakeIamgesToolStripMenuItem;
		private: System::ComponentModel::IContainer^  components;


	#pragma region Windows Form Designer generated code
		
			/*The init function*/
			void InitializeComponent(void)
			{
				this->components = (gcnew System::ComponentModel::Container());
				this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
				this->addToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
				this->studentToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
				this->adminToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
				this->generalSettingToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
				this->generalToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
				this->advancedToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
				this->searchToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
				this->trainToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
				this->retakeIamgesToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
				this->helpToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
				this->aboutToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
				this->exitToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
				this->button2 = (gcnew System::Windows::Forms::Button());
				this->label1 = (gcnew System::Windows::Forms::Label());
				this->label2 = (gcnew System::Windows::Forms::Label());
				this->label3 = (gcnew System::Windows::Forms::Label());
				this->timer1 = (gcnew System::Windows::Forms::Timer(this->components));
				this->menuStrip1->SuspendLayout();
				this->SuspendLayout();
				// 
				// menuStrip1
				// 
				this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(8) {
					this->addToolStripMenuItem,
						this->generalSettingToolStripMenuItem, this->searchToolStripMenuItem, this->trainToolStripMenuItem, this->retakeIamgesToolStripMenuItem,
						this->helpToolStripMenuItem, this->aboutToolStripMenuItem, this->exitToolStripMenuItem
				});
				this->menuStrip1->Location = System::Drawing::Point(0, 0);
				this->menuStrip1->Name = L"menuStrip1";
				this->menuStrip1->Size = System::Drawing::Size(538, 28);
				this->menuStrip1->TabIndex = 4;
				this->menuStrip1->Text = L"menuStrip1";
				// 
				// addToolStripMenuItem
				// 
				this->addToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {
					this->studentToolStripMenuItem,
						this->adminToolStripMenuItem
				});
				this->addToolStripMenuItem->Name = L"addToolStripMenuItem";
				this->addToolStripMenuItem->Size = System::Drawing::Size(49, 24);
				this->addToolStripMenuItem->Text = L"Add";
				this->addToolStripMenuItem->Click += gcnew System::EventHandler(this, &Admin::addToolStripMenuItem_Click);
				// 
				// studentToolStripMenuItem
				// 
				this->studentToolStripMenuItem->Name = L"studentToolStripMenuItem";
				this->studentToolStripMenuItem->Size = System::Drawing::Size(129, 24);
				this->studentToolStripMenuItem->Text = L"Student";
				this->studentToolStripMenuItem->Click += gcnew System::EventHandler(this, &Admin::studentToolStripMenuItem_Click);
				// 
				// adminToolStripMenuItem
				// 
				this->adminToolStripMenuItem->Enabled = false;
				this->adminToolStripMenuItem->Name = L"adminToolStripMenuItem";
				this->adminToolStripMenuItem->Size = System::Drawing::Size(129, 24);
				this->adminToolStripMenuItem->Text = L"Admin";
				this->adminToolStripMenuItem->Click += gcnew System::EventHandler(this, &Admin::adminToolStripMenuItem_Click);
				this->adminToolStripMenuItem->MouseHover += gcnew System::EventHandler(this, &Admin::adminToolStripMenuItem_MouseHover);
				// 
				// generalSettingToolStripMenuItem
				// 
				this->generalSettingToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {
					this->generalToolStripMenuItem,
						this->advancedToolStripMenuItem
				});
				this->generalSettingToolStripMenuItem->Name = L"generalSettingToolStripMenuItem";
				this->generalSettingToolStripMenuItem->Size = System::Drawing::Size(74, 24);
				this->generalSettingToolStripMenuItem->Text = L"Settings";
				this->generalSettingToolStripMenuItem->Click += gcnew System::EventHandler(this, &Admin::generalSettingToolStripMenuItem_Click);
				// 
				// generalToolStripMenuItem
				// 
				this->generalToolStripMenuItem->Name = L"generalToolStripMenuItem";
				this->generalToolStripMenuItem->Size = System::Drawing::Size(144, 24);
				this->generalToolStripMenuItem->Text = L"General";
				this->generalToolStripMenuItem->Click += gcnew System::EventHandler(this, &Admin::generalToolStripMenuItem_Click);
				// 
				// advancedToolStripMenuItem
				// 
				this->advancedToolStripMenuItem->Enabled = false;
				this->advancedToolStripMenuItem->Name = L"advancedToolStripMenuItem";
				this->advancedToolStripMenuItem->Size = System::Drawing::Size(144, 24);
				this->advancedToolStripMenuItem->Text = L"Advanced";
				// 
				// searchToolStripMenuItem
				// 
				this->searchToolStripMenuItem->Name = L"searchToolStripMenuItem";
				this->searchToolStripMenuItem->Size = System::Drawing::Size(65, 24);
				this->searchToolStripMenuItem->Text = L"Search";
				this->searchToolStripMenuItem->Click += gcnew System::EventHandler(this, &Admin::searchToolStripMenuItem_Click);
				// 
				// trainToolStripMenuItem
				// 
				this->trainToolStripMenuItem->Name = L"trainToolStripMenuItem";
				this->trainToolStripMenuItem->Size = System::Drawing::Size(54, 24);
				this->trainToolStripMenuItem->Text = L"Train";
				this->trainToolStripMenuItem->Click += gcnew System::EventHandler(this, &Admin::trainToolStripMenuItem_Click);
				// 
				// retakeIamgesToolStripMenuItem
				// 
				this->retakeIamgesToolStripMenuItem->Name = L"retakeIamgesToolStripMenuItem";
				this->retakeIamgesToolStripMenuItem->Size = System::Drawing::Size(118, 24);
				this->retakeIamgesToolStripMenuItem->Text = L"Retake Iamges";
				this->retakeIamgesToolStripMenuItem->Click += gcnew System::EventHandler(this, &Admin::retakeIamgesToolStripMenuItem_Click);
				// 
				// helpToolStripMenuItem
				// 
				this->helpToolStripMenuItem->Name = L"helpToolStripMenuItem";
				this->helpToolStripMenuItem->Size = System::Drawing::Size(53, 24);
				this->helpToolStripMenuItem->Text = L"Help";
				// 
				// aboutToolStripMenuItem
				// 
				this->aboutToolStripMenuItem->Name = L"aboutToolStripMenuItem";
				this->aboutToolStripMenuItem->Size = System::Drawing::Size(62, 24);
				this->aboutToolStripMenuItem->Text = L"About";
				this->aboutToolStripMenuItem->Click += gcnew System::EventHandler(this, &Admin::aboutToolStripMenuItem_Click);
				// 
				// exitToolStripMenuItem
				// 
				this->exitToolStripMenuItem->Name = L"exitToolStripMenuItem";
				this->exitToolStripMenuItem->Size = System::Drawing::Size(45, 24);
				this->exitToolStripMenuItem->Text = L"Exit";
				this->exitToolStripMenuItem->Click += gcnew System::EventHandler(this, &Admin::exitToolStripMenuItem_Click);
				// 
				// button2
				// 
				this->button2->Location = System::Drawing::Point(398, 319);
				this->button2->Name = L"button2";
				this->button2->Size = System::Drawing::Size(116, 36);
				this->button2->TabIndex = 32;
				this->button2->Text = L"Back";
				this->button2->UseVisualStyleBackColor = true;
				this->button2->Visible = false;
				// 
				// label1
				// 
				this->label1->AutoSize = true;
				this->label1->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 19.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
					static_cast<System::Byte>(0)));
				this->label1->Location = System::Drawing::Point(12, 44);
				this->label1->Name = L"label1";
				this->label1->Size = System::Drawing::Size(168, 46);
				this->label1->TabIndex = 33;
				this->label1->Text = L"Welcome!";
				// 
				// label2
				// 
				this->label2->AutoSize = true;
				this->label2->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 18, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
					static_cast<System::Byte>(0)));
				this->label2->Location = System::Drawing::Point(196, 48);
				this->label2->Name = L"label2";
				this->label2->Size = System::Drawing::Size(193, 42);
				this->label2->TabIndex = 34;
				this->label2->Text = L"Enter Name:";
				// 
				// label3
				// 
				this->label3->AutoSize = true;
				this->label3->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
					static_cast<System::Byte>(0)));
				this->label3->Location = System::Drawing::Point(15, 327);
				this->label3->Name = L"label3";
				this->label3->Size = System::Drawing::Size(145, 28);
				this->label3->TabIndex = 35;
				this->label3->Text = L"Date and Time";
				// 
				// timer1
				// 
				this->timer1->Enabled = true;
				this->timer1->Tick += gcnew System::EventHandler(this, &Admin::timer1_Tick);
				// 
				// Admin
				// 
				this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
				this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
				this->ClientSize = System::Drawing::Size(538, 375);
				this->Controls->Add(this->label3);
				this->Controls->Add(this->label2);
				this->Controls->Add(this->label1);
				this->Controls->Add(this->button2);
				this->Controls->Add(this->menuStrip1);
				this->MainMenuStrip = this->menuStrip1;
				this->Name = L"Admin";
				this->Text = L"Admin";
				this->Load += gcnew System::EventHandler(this, &Admin::Admin_Load);
				this->menuStrip1->ResumeLayout(false);
				this->menuStrip1->PerformLayout();
				this->ResumeLayout(false);
				this->PerformLayout();

			}
			System::DateTime thisisdate;
			int y;
		
		
		
		private: System::Void studentToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
		
			/*New Student Module*/
			NewStudent ^ newstudent = gcnew NewStudent();
			newstudent->Show();		
		}
		private: System::Void exitToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			/*exit, hide this form*/
			this->Hide();
		}
		private: System::Void Admin_Load(System::Object^  sender, System::EventArgs^  e) {
			/*Load Admin Module*/
			System::String^user = gcnew System::String(__Admin_Current_User.c_str());
			label2->Text = user;
		}
		private: System::Void adminToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			/*make new user*/
			int index;
			MyForm^newuser = gcnew MyForm();
			newuser->Show();
		}
		private: System::Void addToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			/*Super User Access*/
			if (__Access_Level == 2)
				adminToolStripMenuItem->Enabled = true;	
		}
		private: System::Void adminToolStripMenuItem_MouseHover(System::Object^  sender, System::EventArgs^  e) {
			/*Admin doesn't have access to superuser priveleges*/
			if (__Access_Level == 1)
				MessageBox::Show("You Do not have access to these features", "Sorry");
		}
		private: System::Void aboutToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			MessageBox::Show("We bring to you a revolutionary breakthrough in the field of facial recognition. Backed with a User-friendly GUI and Database management system, We have one of the most complicated HMM Models to make out algorithm more acccurate. For more, visit: http://www.github.com/cheekujodhpur/cs101", "Visual ATtendance Packagae,2014" , MessageBoxButtons::OK, MessageBoxIcon::Information);
		}
		private: System::Void generalSettingToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
		}
		private: System::Void timer1_Tick(System::Object^  sender, System::EventArgs^  e) {
			/*update time ticker*/
			label3->Text = thisisdate.Now.ToString();
		}
		private: System::Void generalToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			/*make new settings form object*/
			Settings^ newsetting = gcnew Settings();
			newsetting->Show();
		}
		private: System::Void searchToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			/*make new search form object*/
			Search^ newsearch = gcnew Search();
			newsearch->Show();
		}
		private: System::Void retakeIamgesToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			/*New Retake Images Form*/
			Retake ^retake = gcnew Retake();
			retake->Show();
		}
		private: System::Void trainToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
	
			/*
			* With all the data that we have per user, we train our FisherFace Model
			*/

			/*Variable Declarations*/
			string rollno;
			string filename;

			/*Read Current Student Index*/
			ifstream InFile;
			InFile.open("stu_index.txt");
			InFile >> __Student_Current_Index;
			InFile.close();
	
			/*Create model object*/
			Ptr<FaceRecognizer> model = createFisherFaceRecognizer(__Num_Eigenfaces,__Threshold);

			/*Make input vectors for training*/
			vector<Mat> images;
			vector<int> labels;
			/*temporary mat*/
			Mat _tmp_;
	
			/*Take student file storage*/
			cv::FileStorage f("students.yml", cv::FileStorage::READ);
			Student_Info student;
			for (int j = 0; j < __Student_Current_Index; j++)
			{
				/*For all students*/
				string temp = "s_" + to_string(j);
				f[temp] >> student;
				rollno = student.roll_no;

				for (int i = 0; i < 10; i++)
				{
					filename = rollno + "/" + to_string(i) + ".jpg";
					_tmp_ = imread(filename.c_str(), 0);
					/*Read image and resize*/
					resize(_tmp_, _tmp_, Size2d(96, 96), 0, 0, CV_INTER_LINEAR);

					/*push into images and labels vector*/
					images.push_back(_tmp_);
					labels.push_back(j);
				}
			}
			//train FisherFace Model and save it
			model->train(images, labels);
			model->save("modelo.yml");

		}
	};
}
#pragma endregion