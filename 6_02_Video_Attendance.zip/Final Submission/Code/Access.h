#ifndef ACCESS_H
#define ACCESS_H
extern int accessnumber;
#endif