/*
A Video Attendance Module
Copyright (C) Slot 6:Group 2:Reebhu,Keshav,Ayush,Kshitij

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
*/

#pragma once
/*Library Headers*/
#include<iostream>
#include<opencv2\core\core.hpp>
#include<stdlib.h>
#include <iostream>
#include <fstream>
#include <string>

/*Header Files*/
#include"Main.h"
#include "Detect.h"

namespace VAM {

	/*namespaces*/
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

		public ref class NewStudent : public System::Windows::Forms::Form
		{
		public:
			/*Constructor*/
			NewStudent(void)
			{
				/*Init function*/
				InitializeComponent();
			}

		protected:
			~NewStudent()
			{
				if (components)
				{
					delete components;
				}
			}
		/*Form Components*/
		private: System::Windows::Forms::TextBox^  textBox2;
		private: System::Windows::Forms::TextBox^  textBox3;
		private: System::Windows::Forms::Label^  label1;
		private: System::Windows::Forms::Label^  label2;
		private: System::Windows::Forms::Label^  label3;
		private: System::Windows::Forms::Label^  label4;
		private: System::Windows::Forms::Button^  button3;
		private: System::Windows::Forms::Button^  button1;
		private: System::Windows::Forms::Button^  button2;
		private: System::Windows::Forms::ProgressBar^  progressBar1;
		private: System::Windows::Forms::Button^  button4;
		/*Form component initializer*/
		private: System::ComponentModel::Container ^components;

	#pragma region Windows Form Designer generated code
			/*Init Function Definition*/
			void InitializeComponent(void)
			{
				this->textBox2 = (gcnew System::Windows::Forms::TextBox());
				this->textBox3 = (gcnew System::Windows::Forms::TextBox());
				this->label1 = (gcnew System::Windows::Forms::Label());
				this->label2 = (gcnew System::Windows::Forms::Label());
				this->label3 = (gcnew System::Windows::Forms::Label());
				this->label4 = (gcnew System::Windows::Forms::Label());
				this->button3 = (gcnew System::Windows::Forms::Button());
				this->button1 = (gcnew System::Windows::Forms::Button());
				this->button2 = (gcnew System::Windows::Forms::Button());
				this->progressBar1 = (gcnew System::Windows::Forms::ProgressBar());
				this->button4 = (gcnew System::Windows::Forms::Button());
				this->SuspendLayout();
				// 
				// textBox2
				// 
				this->textBox2->Location = System::Drawing::Point(308, 84);
				this->textBox2->Name = L"textBox2";
				this->textBox2->Size = System::Drawing::Size(252, 22);
				this->textBox2->TabIndex = 11;
				// 
				// textBox3
				// 
				this->textBox3->Location = System::Drawing::Point(308, 148);
				this->textBox3->Name = L"textBox3";
				this->textBox3->Size = System::Drawing::Size(252, 22);
				this->textBox3->TabIndex = 12;
				// 
				// label1
				// 
				this->label1->AutoSize = true;
				this->label1->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
					static_cast<System::Byte>(0)));
				this->label1->Location = System::Drawing::Point(78, 78);
				this->label1->Name = L"label1";
				this->label1->Size = System::Drawing::Size(127, 28);
				this->label1->TabIndex = 13;
				this->label1->Text = L"Enter Name:";
				// 
				// label2
				// 
				this->label2->AutoSize = true;
				this->label2->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
					static_cast<System::Byte>(0)));
				this->label2->Location = System::Drawing::Point(59, 142);
				this->label2->Name = L"label2";
				this->label2->Size = System::Drawing::Size(189, 28);
				this->label2->TabIndex = 14;
				this->label2->Text = L"Enter Roll Number:";
				// 
				// label3
				// 
				this->label3->AutoSize = true;
				this->label3->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
					static_cast<System::Byte>(0)));
				this->label3->Location = System::Drawing::Point(78, 213);
				this->label3->Name = L"label3";
				this->label3->Size = System::Drawing::Size(111, 28);
				this->label3->TabIndex = 15;
				this->label3->Text = L"Unique ID:";
				// 
				// label4
				// 
				this->label4->AutoSize = true;
				this->label4->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
					static_cast<System::Byte>(0)));
				this->label4->Location = System::Drawing::Point(359, 213);
				this->label4->Name = L"label4";
				this->label4->Size = System::Drawing::Size(0, 28);
				this->label4->TabIndex = 16;
				// 
				// button3
				// 
				this->button3->Location = System::Drawing::Point(40, 281);
				this->button3->Name = L"button3";
				this->button3->Size = System::Drawing::Size(116, 36);
				this->button3->TabIndex = 17;
				this->button3->Text = L"Back";
				this->button3->UseVisualStyleBackColor = true;
				this->button3->Click += gcnew System::EventHandler(this, &NewStudent::button3_Click);
				// 
				// button1
				// 
				this->button1->Location = System::Drawing::Point(237, 281);
				this->button1->Name = L"button1";
				this->button1->Size = System::Drawing::Size(116, 36);
				this->button1->TabIndex = 18;
				this->button1->Text = L"Clear";
				this->button1->UseVisualStyleBackColor = true;
				this->button1->Click += gcnew System::EventHandler(this, &NewStudent::button1_Click);
				// 
				// button2
				// 
				this->button2->Location = System::Drawing::Point(444, 281);
				this->button2->Name = L"button2";
				this->button2->Size = System::Drawing::Size(116, 36);
				this->button2->TabIndex = 19;
				this->button2->Text = L"Create";
				this->button2->UseVisualStyleBackColor = true;
				this->button2->Click += gcnew System::EventHandler(this, &NewStudent::button2_Click);
				// 
				// progressBar1
				// 
				this->progressBar1->Location = System::Drawing::Point(161, 116);
				this->progressBar1->Name = L"progressBar1";
				this->progressBar1->Size = System::Drawing::Size(272, 36);
				this->progressBar1->TabIndex = 20;
				this->progressBar1->Visible = false;
				// 
				// button4
				// 
				this->button4->Location = System::Drawing::Point(468, 23);
				this->button4->Name = L"button4";
				this->button4->Size = System::Drawing::Size(116, 36);
				this->button4->TabIndex = 21;
				this->button4->Text = L"Add New ";
				this->button4->UseVisualStyleBackColor = true;
				this->button4->Visible = false;
				this->button4->Click += gcnew System::EventHandler(this, &NewStudent::button4_Click);
				// 
				// NewStudent
				// 
				this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
				this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
				this->ClientSize = System::Drawing::Size(611, 344);
				this->Controls->Add(this->button4);
				this->Controls->Add(this->progressBar1);
				this->Controls->Add(this->button2);
				this->Controls->Add(this->button1);
				this->Controls->Add(this->button3);
				this->Controls->Add(this->label4);
				this->Controls->Add(this->label3);
				this->Controls->Add(this->label2);
				this->Controls->Add(this->label1);
				this->Controls->Add(this->textBox3);
				this->Controls->Add(this->textBox2);
				this->Name = L"NewStudent";
				this->Text = L"NewStudent";
				this->ResumeLayout(false);
				this->PerformLayout();

			}
		
	#pragma endregion
		private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {
			/*Close*/
			textBox2->Text = "";
			textBox3->Text = "";
			label4->Text = "";
			this->Hide();
		}
		private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			/*Clear*/
			textBox2->Text = "";
			textBox3->Text = "";
			label4->Text = "";
		}
		private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
			int index;

			/*InFile declaration for getting Student Current Index*/
			ifstream InFile;
			InFile.open("stu_index.txt");
			InFile>>index;
			__Student_Current_Index = index;
			InFile.close();

			/*Temp Strings*/
			string text1, text2, temp;
			System::String^ labeltext;
			Student_Info newstudent;

			/*File Storage read*/
			cv::FileStorage f("students.yml", cv::FileStorage::READ);
			MarshalString(textBox2->Text, text1);
			MarshalString(textBox3->Text, text2);
			
			bool flag = true;
			for (int j = 0; j < __Student_Current_Index; j++)
			{
				temp = "s_" + to_string(j);
				f[temp] >> newstudent;
				if (newstudent.roll_no == text2)
				{
					MessageBox::Show("Roll Number Already in Database");
					flag = false;
				}
			}
			f.release();

			/*Hide stuff*/
			textBox2->Visible = false;
			textBox3->Visible = false;
			label1->Text = "";
			label2->Text = "";
			if (flag)
				{
					/*Make new student*/
					__File_Number = 0;
					cv::FileStorage f("students.yml", cv::FileStorage::APPEND);
					newstudent.name = text1;
					newstudent.roll_no = text2;
					string outputfolder = text2;
					temp = "s_" + to_string(__Student_Current_Index);
					System::String ^unique_id = gcnew System::String(temp.c_str());
					f << temp << newstudent;

					/*Update student index*/
					__Student_Current_Index++;
					/*Write to file*/
					ofstream OutFile("stu_index.txt");
					OutFile << __Student_Current_Index;
					OutFile.close();

					/*Message*/
					MessageBox::Show("Please Stay Still As Photos are taken ", "Attention!", MessageBoxButtons::OK, MessageBoxIcon::Information);
					progressBar1->Visible = true;
					button1->Visible = false;
					button2->Visible = false;
					button4->Visible = true; 
					label4->Text = unique_id;
					textBox2->Text = "";
					textBox3->Text = "";
					
					/*dummy*/
					int y;
					do
					{
							y = videoFaceDetect(outputfolder);
						progressBar1->Value = (y * 100 / __Num_Photos);

					} while (y < __Num_Photos);
					progressBar1->Visible = false;
					MessageBox::Show("Done!");
			
				}
		
		}
		private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) {
			/**/
			button1->Visible = true;
			button2->Visible = true;
			button4->Visible = false;
			label4->Text = "";
			textBox2->Text = "";
			textBox2->Visible = true;
			textBox3->Text = "";
			textBox3->Visible = true;
		}
	};
}
