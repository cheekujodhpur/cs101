/*
A Video Attendance Module
Copyright (C) Slot 6:Group 2:Reebhu,Keshav,Ayush,Kshitij

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
*/


#pragma once

/*External Libraries*/
#include <opencv2/core/core.hpp>
#include <iostream>
#include <string>

/*Header FIles*/
#include "Marshal.h"

/*Namespaces*/
using namespace std;
using namespace System;

/*Global Variables*/
extern int __Student_Current_Index;
extern int __Access_Level;
extern int __Num_Photos;
extern int __Admin_Current_Index;
extern int __File_Number;
extern int __Num_Eigenfaces;
extern double __Threshold;
extern string __Admin_Current_User;

/*Admin Info Clas*/
class Admin_Info
{
public:
	Admin_Info() : admin_access(100),  password()
	{}
	explicit Admin_Info(int) : admin_access(97), password("admin123") // explicit to avoid implicit conversion
	{}
	void write(cv::FileStorage& fs) const                        //Write serialization for this class
	{
		fs << "{" << "admin_access" << admin_access << "password" << password << "}";
	}
	void read(const cv::FileNode& node)                          //Read serialization for this class
	{
		admin_access = (int)node["admin_access"];
		password = (string)node["password"];
	}
public:   // Data Members
	int admin_access;
	string password;
};

//These write and read functions must be defined for the serialization in FileStorage to work
static void write(cv::FileStorage& fs, const std::string&, const Admin_Info& x)
{
	x.write(fs);
}
static void read(const cv::FileNode& node, Admin_Info& x, const Admin_Info& default_value = Admin_Info()){
	if (node.empty())
		x = default_value;
	else
		x.read(node);
}

// This function will print our custom class to the console
static ostream& operator<<(ostream& out, const Admin_Info& m)
{
	out << "{ password = " << m.password << ", ";
	out << "admin_access = " << m.admin_access << "}";
	return out;
}
class Student_Info
{
public:
	Student_Info() : name(), roll_no("void")
	{}
	explicit Student_Info(int) : roll_no("97"), name("Hi") // explicit to avoid implicit conversion
	{}
	void write(cv::FileStorage& fs) const                        //Write serialization for this class
	{
		fs << "{" << "roll_no" << roll_no << "name" << name << "}";
	}
	void read(const cv::FileNode& node)                          //Read serialization for this class
	{
		roll_no = (string)node["roll_no"];
		name = (string)node["name"];
	}
public:   // Data Members
	string roll_no;
	string name;
};

//These write and read functions must be defined for the serialization in FileStorage to work
static void write(cv::FileStorage& fs, const std::string&, const Student_Info& x)
{
	x.write(fs);
}
static void read(const cv::FileNode& node, Student_Info& x, const Student_Info& default_value = Student_Info()){
	if (node.empty())
		x = default_value;
	else
		x.read(node);
}

#pragma endregion