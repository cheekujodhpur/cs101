/*
A Video Attendance Module
Copyright (C) Slot 6:Group 2:Reebhu,Keshav,Ayush,Kshitij

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
*/

#pragma once
#include<iostream>
#include<opencv2/core/core.hpp>
#include"Main.h"

using namespace std;

/*void ChangeString(String^ s, string& os) {
	using namespace Runtime::InteropServices;
	const char* chars =
		(const char*)(Marshal::StringToHGlobalAnsi(s)).ToPointer();
	os = chars;
	Marshal::FreeHGlobal(IntPtr((void*)chars));
}*/
namespace VAM {

	/*namespaces*/
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

		public ref class MyForm : public System::Windows::Forms::Form
		{
		public:
			/*constructor*/
			MyForm(void)
			{
				/*Init function*/
				InitializeComponent();
			}

		protected:
			/*Destructor*/
			~MyForm()
			{
				if (components)
				{
					delete components;
				}
			}
		/*Form components*/
		private: System::Windows::Forms::Button^  button2;
		private: System::Windows::Forms::Button^  button1;
		private: System::Windows::Forms::Label^  label1;
		private: System::Windows::Forms::Label^  label2;
		private: System::Windows::Forms::Label^  label3;
		private: System::Windows::Forms::TextBox^  textBox1;
		private: System::Windows::Forms::TextBox^  textBox2;
		private: System::Windows::Forms::TextBox^  textBox3;
	   /*Declare all components*/
		private: System::ComponentModel::Container ^components;

	#pragma region Windows Form Designer generated code
			 /*Init function definition*/
			void InitializeComponent(void)
			{
				this->button2 = (gcnew System::Windows::Forms::Button());
				this->button1 = (gcnew System::Windows::Forms::Button());
				this->label1 = (gcnew System::Windows::Forms::Label());
				this->label2 = (gcnew System::Windows::Forms::Label());
				this->label3 = (gcnew System::Windows::Forms::Label());
				this->textBox1 = (gcnew System::Windows::Forms::TextBox());
				this->textBox2 = (gcnew System::Windows::Forms::TextBox());
				this->textBox3 = (gcnew System::Windows::Forms::TextBox());
				this->SuspendLayout();
				// 
				// button2
				// 
				this->button2->Location = System::Drawing::Point(51, 327);
				this->button2->Name = L"button2";
				this->button2->Size = System::Drawing::Size(116, 36);
				this->button2->TabIndex = 1;
				this->button2->Text = L"Clear";
				this->button2->UseVisualStyleBackColor = true;
				this->button2->Click += gcnew System::EventHandler(this, &MyForm::button2_Click);
				// 
				// button1
				// 
				this->button1->Location = System::Drawing::Point(313, 327);
				this->button1->Name = L"button1";
				this->button1->Size = System::Drawing::Size(116, 36);
				this->button1->TabIndex = 2;
				this->button1->Text = L"Create";
				this->button1->UseVisualStyleBackColor = true;
				this->button1->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
				// 
				// label1
				// 
				this->label1->AutoSize = true;
				this->label1->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
					static_cast<System::Byte>(0)));
				this->label1->Location = System::Drawing::Point(22, 103);
				this->label1->Name = L"label1";
				this->label1->Size = System::Drawing::Size(167, 28);
				this->label1->TabIndex = 3;
				this->label1->Text = L"Enter Username:";
				// 
				// label2
				// 
				this->label2->AutoSize = true;
				this->label2->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
					static_cast<System::Byte>(0)));
				this->label2->Location = System::Drawing::Point(22, 164);
				this->label2->Name = L"label2";
				this->label2->Size = System::Drawing::Size(162, 28);
				this->label2->TabIndex = 4;
				this->label2->Text = L"Enter Password:";
				// 
				// label3
				// 
				this->label3->AutoSize = true;
				this->label3->Font = (gcnew System::Drawing::Font(L"Comic Sans MS", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
					static_cast<System::Byte>(0)));
				this->label3->Location = System::Drawing::Point(12, 227);
				this->label3->Name = L"label3";
				this->label3->Size = System::Drawing::Size(193, 28);
				this->label3->TabIndex = 5;
				this->label3->Text = L"Re-enter Password:";
				// 
				// textBox1
				// 
				this->textBox1->Location = System::Drawing::Point(230, 109);
				this->textBox1->Name = L"textBox1";
				this->textBox1->Size = System::Drawing::Size(252, 22);
				this->textBox1->TabIndex = 6;
				// 
				// textBox2
				// 
				this->textBox2->Location = System::Drawing::Point(230, 170);
				this->textBox2->Name = L"textBox2";
				this->textBox2->Size = System::Drawing::Size(252, 22);
				this->textBox2->TabIndex = 7;
				// 
				// textBox3
				// 
				this->textBox3->Location = System::Drawing::Point(230, 233);
				this->textBox3->Name = L"textBox3";
				this->textBox3->Size = System::Drawing::Size(252, 22);
				this->textBox3->TabIndex = 8;
				// 
				// MyForm
				// 
				this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
				this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
				this->ClientSize = System::Drawing::Size(508, 434);
				this->Controls->Add(this->textBox3);
				this->Controls->Add(this->textBox2);
				this->Controls->Add(this->textBox1);
				this->Controls->Add(this->label3);
				this->Controls->Add(this->label2);
				this->Controls->Add(this->label1);
				this->Controls->Add(this->button1);
				this->Controls->Add(this->button2);
				this->Name = L"MyForm";
				this->Text = L"MyForm";
				this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
				this->ResumeLayout(false);
				this->PerformLayout();

			}
		#pragma endregion
		private: System::Void MyForm_Load(System::Object^  sender, System::EventArgs^  e) {
			/*Use password Vars*/
			textBox2->UseSystemPasswordChar = true;
			textBox3->UseSystemPasswordChar = true;
		}
		private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
			/*Clear*/
			textBox1->Text = "";
			textBox2->Text = "";
			textBox3->Text = "";
		}
		private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			/*Admin Info, during Admin creation*/
			Admin_Info newadmin;
			string usernm, pssword;

			/*String conversion*/
			MarshalString(textBox1->Text, usernm);
			MarshalString(textBox2->Text, pssword);

			/*File to read stuff*/
			cv::FileStorage fx("admin.yml", cv::FileStorage::READ);
			fx[usernm] >> newadmin;

			/*Check if new admin*/
			if (newadmin.admin_access != 100)
			{
				/*Username already taken*/
				MessageBox::Show("Userame Already Taken", "Sorry");
			}
			else if (textBox2->Text != textBox3->Text)
			{
				/*Passwords don't match*/
				MessageBox::Show("Passwords don't match!", "Check");
				textBox2->Text = "";
				textBox3->Text = "";
			}
			else
			{
				/*Append new admin*/
				cv::FileStorage fx("admin.yml", cv::FileStorage::APPEND);
				newadmin.admin_access = 1;
				newadmin.password = pssword;
				fx << usernm << newadmin;
				MessageBox::Show("New Admin creation succesful!");
				textBox1->Text = "";
				textBox2->Text = "";
				textBox3->Text = "";
			}
		}
	};
}
