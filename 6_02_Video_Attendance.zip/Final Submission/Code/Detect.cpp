/*
A Video Attendance Module
Copyright (C) Slot 6:Group 2:Reebhu,Keshav,Ayush,Kshitij

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
*/

/*External libraries*/
#include <string>
#include <iostream>
#include <direct.h>

/*Header files*/
#include "Main.h"
#include "Detect.h"

/*namespaces*/
using namespace std;
using namespace cv;
using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;


string face_cascade_name = "C:/opencv/sources/data/haarcascades/haarcascade_frontalface_alt.xml";//location of face detector in haar cascades
CascadeClassifier face_cascade;//specify a new CascadeClassifier which will detect faces

int videoFaceDetect(string outputfolder)
{
	CvCapture* capture = cvCaptureFromCAM(CV_CAP_ANY);//declare a variable to detect and obtain input from any attached camera device
//	cvNamedWindow("Webcam", 1);						//create a new window in which to display video streaming from webcam
//	cvNamedWindow("Detected", 1);					//create a new window in which to display the detected face
	Mat img;				//store captured _frame from the video
	Vector<Mat> crop;		//a vector(similar to a dynamic array) of Mat objects(images) which will store the cropped faces 
	
		if (!cvGrabFrame(capture))				//fs if it is possible capture a _frame from the video stream
		{
			cout << "Could not grab _frame from webcam." << endl;
		}
		img = cvRetrieveFrame(capture);			//get the _frame from the video stream;
		int x = (DetectAndCrop(outputfolder,img, crop ));			//fs if user pressed Esc key
		return x;
		
	}
	/*cvReleaseCapture(&capture);			//release the capture stream
	destroyAllWindows();
	return;*/

int DetectAndCrop(string output_folder,Mat &img, Vector<Mat> &output)
{
	vector<Rect> faces;		//Rectangle vector to store rectangles around faces detected
	Mat _frame_gray;			//Store greyscale version of original 
	Mat res;				//Store resized cropped image
	Mat gray;				//Store gray cropped image
	string filename = output_folder;		//filename in which cropped face will be stored
	stringstream ssfn;		//to append number to each filename, depending on image number
	cvtColor(img, _frame_gray, COLOR_BGR2GRAY);	//convert original image to gray
	equalizeHist(_frame_gray, _frame_gray);		//histogram equalization
	if (!face_cascade.load(face_cascade_name))	//see if Cascade has loaded
	{
		cout << "Unable to load." << endl;
		return 0;
	}
	//detect faces in image and store the surrounding rectangle of each face in a vector
	face_cascade.detectMultiScale(_frame_gray, faces, 1.1, 5, 0 | CASCADE_SCALE_IMAGE, Size(30, 30));
	//rectangle object to store each rectangle separately
	Rect roi_c;

	size_t ic = 0; // ic is index of current element
	int ac = 0; // ac is area of current element

	for (ic = 0; ic < faces.size(); ic++) // Iterate through all current elements (detected faces)

	{
		roi_c.x = faces[ic].x;		//store x-coordinate of starting corner of rectangle
		roi_c.y = faces[ic].y;		//store y-coordinate of starting corner of rectangle
		roi_c.width = (faces[ic].width);		//get width of rectangle
		roi_c.height = (faces[ic].height);		//get height of rectangle

		ac = roi_c.width * roi_c.height;// Get the area of current element (detected face)
		output.push_back(img(roi_c));//push the detected and cropped face into the Mat vector
		resize(output[ic], res, Size(128, 128), 0, 0, INTER_LINEAR); // This will be needed later while saving images
		cvtColor(output[ic], gray, CV_BGR2GRAY); // Convert cropped image to Grayscale

		_mkdir(filename.c_str());
		// Form a filename
		filename = filename+"/"+to_string(__File_Number) + ".jpg";
		//convert filename to string
		//increment __File_Number so as to store next image in consecutively numbered file
		__File_Number++; 
		
		
		//store the cropped greyscale image in a file
		try
		{
			if (!imwrite(filename.c_str(), gray))
				throw "Can't write file";
		}
		catch (const char* erro)
		{
			cerr << erro << endl;
		}
		return __File_Number;

	/*	Point pt1(faces[ic].x, faces[ic].y); // Display detected faces on main window - live stream from camera
		Point pt2((faces[ic].x + faces[ic].height), (faces[ic].y + faces[ic].width));
		rectangle(img, pt1, pt2, Scalar(0, 255, 0), 2, 8, 0);	//Display a rectangle around detected face in oiginal image*/
	}
	

}

/*Function to display caption*/
int display_caption(Mat &A, Mat &B, char* ch, char* winname, int del)	//function which displays a text in  a new window
{
	B = Mat::zeros(Size(A.rows, A.cols), A.type());	//create a zero image matrix(black window)
	putText(B, ch, Point(B.cols / 4, B.rows / 4), CV_FONT_HERSHEY_COMPLEX, 1, Scalar(255, 0, 0));
	imshow(winname, B);
	int c = waitKey(del);
	if ((char)c == 27)
		return -1;
	destroyWindow(winname);
	return 0;
}

int display_image(Mat &A, char *winname, int del)		//function to display image 'A' in a window 'winname' for time interval 'del'
{
	imshow(winname, A);		//show image in given window
	int c = waitKey(del);	//wait for user to press Esc for 'del' time interval 
	if ((char)c == 27)	
		return -1;			
	return 0;		//after del time, automatically exit
}

int smoothImage(char *img)
{
	Mat src = imread(img, 1);// read the image specified by the parameter
	Mat dst;	//to store output(destinantion) image
	int kernel_w = 31;		//specify maximum size of kernel
	if (!src.data)return -1;	//if image couldn't be loaded
	dst = src.clone();		//copy the original image and display it
	if (display_image(dst, "Original Image", 1000) != 0) { return 0; }
	/// Applying Homogeneous blur
	if (display_caption(src, dst, "Homogeneous Blur", "Homogeneous Blur", 1000) != 0) { return 0; }
	for (int i = 1; i < kernel_w; i = i + 2)
	{
		blur(src, dst, Size(i, i), Point(-1, -1));
		if (display_image(dst, "Homogenous Blur", 1000) != 0) { return 0; }
	}
	/// Applying Gaussian blur
	if (display_caption(src, dst, "Gaussian Blur", "Gaussian Blur", 1000) != 0) { return 0; }
	for (int i = 1; i < kernel_w; i = i + 2)
	{
		GaussianBlur(src, dst, Size(i, i), 0, 0);
		if (display_image(dst, "Gaussian Blur", 1000) != 0) { return 0; }
	}
	/// Applying Median blur
	if (display_caption(src, dst, "Median Blur", "Median Blur", 1000) != 0) { return 0; }
	for (int i = 1; i < kernel_w; i = i + 2)
	{
		medianBlur(src, dst, i);
		if (display_image(dst, "Median Blur", 1000) != 0) { return 0; }
	}
	///Applying bilateral blur
	if (display_caption(src, dst, "Bilateral Blur", "Bilateral Blur", 1000) != 0) { return 0; }
	for (int i = 1; i < kernel_w; i = i + 2)
	{
		bilateralFilter(src, dst, i, i * 2, i / 2);
		if (display_image(dst, "Bilateral Blur", 1000) != 0) { return 0; }
	}
	waitKey(0);
	/*destroyAllWindows();//destroy all windows showing the images before exiting
	return 0;*/
};

/*If a message box is open*/
bool isopen = false;
void videoFaceDetect2(Mat *img)
{
	Ptr<FaceRecognizer> model = createFisherFaceRecognizer();
	try
	{
		model->load("modelo.yml");
	}
	catch(exception &e) {
		MessageBox::Show("No model file to load");
	}
	vector<Rect> faces;		//Rectangle vector to store rectangles around faces detected
	Mat _frame_gray;			//Store greyscale version of original 
	Mat res;				//Store resized cropped image
	Mat gray;				//Store gray cropped image
	string filename;		//filename in which cropped face will be stored
	stringstream ssfn;		//to append number to each filename, depending on image number
	cvtColor(*img, _frame_gray, COLOR_BGR2GRAY);	//convert original image to gray
	if (!face_cascade.load(face_cascade_name))	//see if Cascade has loaded
	{
		cout << "Unable to load." << endl;
		return;
	}
	//detect faces in image and store the surrounding rectangle of each face in a vector
	face_cascade.detectMultiScale(_frame_gray, faces, 1.1, 5, 0 | CASCADE_SCALE_IMAGE, Size(30, 30));
	cv::FileStorage f("students.yml", cv::FileStorage::READ);
	Student_Info student;
	//rectangle object to store each rectangle separately
	cv::Rect roi_c;
	size_t ic = 0; // ic is index of current element
	int ac = 0; // ac is area of current element
	for(ic = 0; ic < faces.size(); ic++) // Iterate through all current elements (detected faces)

	{
		roi_c.x = faces[ic].x;		//store x-coordinate of starting corner of rectangle
		roi_c.y = faces[ic].y;		//store y-coordinate of starting corner of rectangle
		roi_c.width = (faces[ic].width);		//get width of rectangle
		roi_c.height = (faces[ic].height);		//get height of rectangle
		Mat detectable = (*img)(roi_c);//push the detected and cropped face into the Mat vector
		cvtColor(detectable, detectable, CV_BGR2GRAY);
		resize(detectable, detectable, Size2d(96, 96), 0, 0, CV_INTER_LINEAR);
		double __Threshold = 0.0;
		int predictedLabel;
		try
		{
			model->predict(detectable, predictedLabel, __Threshold);
		}
		catch (exception &e)
		{
			;
		}
		int output = (__Threshold>1000) ? predictedLabel : (-1);
		Point pt1(faces[ic].x, faces[ic].y); // Display detected faces on main window - live stream from camera
		Point pt2((faces[ic].x + faces[ic].height), (faces[ic].y + faces[ic].width));
		if (output != -1)
		{
			rectangle(*img, pt1, pt2, Scalar(0, 255, 0), 2, 8, 0);	//Display a rectangle around detected face in oiginal image
			string s = "s_" + to_string(output);
			f[s] >> student;
			s = "Are you " + student.name + ":" + student.roll_no + "?";
			System::String^ _tmp = gcnew System::String(s.c_str());
			if (!isopen)
			{
				isopen = true;
				System::Windows::Forms::DialogResult res_msg = MessageBox::Show(_tmp, "Confirm Identity", MessageBoxButtons::OKCancel);
				isopen = false;
				if (res_msg == System::Windows::Forms::DialogResult::OK)
				{
					;
					/*
					* The code to mark attendance comes here
					* This can link to an external SQL database
					* or something like that
					*/
				}
			}
		}
		else
		{
			rectangle(*img, pt1, pt2, Scalar(0, 0, 255), 2, 8, 0);
		}
	}
}